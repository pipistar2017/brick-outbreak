extends Node3D

const HeroVisual = preload("res://hero_model.gd")
const CombatFX = preload("res://combat_fx.gd")
const ZombieVisual = preload("res://zombie_model.gd")
const BattleCamera = preload("res://battle_camera.gd")
const Campaign = preload("res://campaign_data.gd")
const CampaignEnemy = preload("res://campaign_enemy.gd")
const VictoryArrival = preload("res://victory_arrival.gd")
var ending: Node3D
var ending_preview := false
const ClickNavigation = preload("res://click_navigation.gd")
var click_path: Array[Vector3] = []
const EnemyProjectile = preload("res://enemy_projectile.gd")
const EnergyCircle = preload("res://energy_circle.gd")
var circle: Node3D
var circle_target: Dictionary = {}
var circle_destroyed := false
var circle_preview := -1
var enemy_preview := -1

const StageWorld = preload("res://stage_world.gd")
var stage_index := 0
var wave_index := 0
var wave_spawned := 0
var stage_spawned := 0
var stage_kills := 0
var stage_cleared := false
var between_stages := false
var campaign_won := false
var gallery_stage := 0
var stage_scenes: Array = [null,null,null]
var stage_hud: Label
var sky: Environment
var sunlight: DirectionalLight3D
var stage_preview := -1
var stage_demo := false
var stage_demo_tick := 0

const HEROES = [
	{"name":"青龙战将", "role":"近战 · 血量 220 / 300 / 350\n普攻 30 · 间隔 0.8 秒", "hp":220.0,"stage_hp":[220.0,300.0,350.0],"q_radius":6.0,"q_damage":70.0,"damage":30.0,"rate":0.8,"color":Color("21c78b"),"q":6.0,"e":14.0},
	{"name":"赤焰游侠", "role":"速射 · 血量 160 / 200 / 260\n普攻 18 · 间隔 0.35 秒", "hp":160.0,"stage_hp":[160.0,200.0,260.0],"q_radius":10.0,"q_damage":75.0,"damage":18.0,"rate":0.35,"color":Color("ff884b"),"q":5.0,"e":16.0},
	{"name":"寒霜术士", "role":"冰霜 · 血量 180 / 220 / 260\n普攻 24 · 间隔 0.7 秒", "hp":180.0,"stage_hp":[180.0,220.0,260.0],"q_radius":8.0,"q_damage":45.0,"damage":24.0,"rate":0.7,"color":Color("64c9ff"),"q":7.0,"e":16.0}
]
const SKILL_NAMES = [["青龙横扫","破阵突击","绝气斩"],["爆裂弹","火力全开","火球天降"],["冰霜新星","极寒爆发","四方霜降"]]
const THIRD_COOLDOWN := 20.0
const DRAGON_RANGE := 48.0
const DRAGON_HALF_WIDTH := 1.6
const FROST_RADIUS := 6.0
const FROST_HALF_WIDTH := 0.95
const FROST_PULSES := 12
var w_clock := 0.0
var armor_bonus := 0.0
var difficulty := 1
var difficulty_picker: OptionButton
var ultimate_jobs: Array = []
var frost_age := -1.0
var frost_pulses := 0
var frost_heading := Vector3.FORWARD
var skill_preview := -1
var ultimate_demo := false
var ultimate_demo_tick := 0

const ENEMIES = [
	{"hp":60.0,"damage":10.0,"speed":1.35,"color":Color("85997a"),"scale":1.0},
	{"hp":40.0,"damage":8.0,"speed":2.8,"color":Color("a0ab78"),"scale":0.8},
	{"hp":240.0,"damage":25.0,"speed":0.8,"color":Color("928a96"),"scale":1.45},
	{"hp":80.0,"damage":15.0,"speed":1.0,"color":Color("a2aa62"),"scale":1.0},
	{"hp":1800.0,"damage":30.0,"speed":1.15,"color":Color("687c65"),"scale":2.5},
	{"hp":300.0,"damage":28.0,"speed":1.1,"color":Color("8b8d82"),"scale":1.35}
]
var fx: Node3D
var shots: Array = []
var swings: Array = []
var skill_buttons: Array = []
var banner: Label
var banner_hint: Label
var banner_time := 0.0
var shake_strength := 0.0
var white_flash: StandardMaterial3D
var ice_overlay: StandardMaterial3D
var combat_preview := -1
var demo_tick := 0
var combat_demo := false
var world: Node3D
var player: Node3D
var view_rig: RefCounted
var view_button: Button
var view_hint: Label
var view_controls: Array = []
var view_drag := false
var camera_preview := -1
var camera_demo := false
var camera_tick := 0
var camera: Camera3D
var ui: CanvasLayer
var hud: Label
var status: Label
var hp_bar: ProgressBar
var menu: Control
var enemies: Array = []
var bullets: Array = []
var hero := 0
var hp := 220.0
var max_hp := 220.0
var elapsed := 0.0
var spawn_clock := 0.0
var attack_clock := 0.0
var q_clock := 0.0
var e_clock := 0.0
var invuln := 0.0
var dash_clock := 0.0
var buff := 0.0
var kills := 0
var xp := 0
var level := 1
var damage_mult := 1.0
var playing := false
var choosing := false
var paused := false
var boss_spawned := false
var direction := Vector3.FORWARD
var portrait_rigs: Array = []
var zombie_preview := false
var menu_preview := false
var preview := false
var preview_frames := 0
var auto_test := false
var test_steps := 0
var sound: AudioStreamPlayer
var synth: AudioStreamGeneratorPlayback

func material(color: Color, glow := false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.65
	if glow:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = 1.5
	return m

func box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var mesh := MeshInstance3D.new()
	var shape := BoxMesh.new()
	shape.size = size
	mesh.mesh = shape
	mesh.material_override = material(color)
	mesh.position = pos
	parent.add_child(mesh)
	return mesh


func _ready() -> void:
	if "--build-info" in OS.get_cmdline_user_args():
		if FileAccess.file_exists("res://assets/build-info.json"):
			print("BUILD_INFO:"+FileAccess.get_file_as_string("res://assets/build-info.json").replace("\n",""))
			get_tree().quit(0)
		else:
			push_error("Missing build manifest")
			get_tree().quit(1)
		return
	auto_test = "--smoke-test" in OS.get_cmdline_user_args()
	world = Node3D.new()
	add_child(world)
	fx = CombatFX.new()
	world.add_child(fx)
	white_flash = StandardMaterial3D.new()
	white_flash.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	white_flash.albedo_color = Color("fff1c9")
	ice_overlay = StandardMaterial3D.new()
	ice_overlay.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ice_overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ice_overlay.albedo_color = Color(0.4,0.85,1.0,0.28)
	var env := WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_SKY
	sky = env.environment
	sky.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	sky.tonemap_exposure = 0.85
	sky.sky = Sky.new()
	sky.sky.sky_material = ProceduralSkyMaterial.new()
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color("b0c5e0")
	env.environment.ambient_light_energy = 0.28
	add_child(env)
	var sun := DirectionalLight3D.new()
	sunlight = sun
	sun.rotation_degrees = Vector3(-55,-35,0)
	sun.light_color = Color("ffe5b0")
	sun.light_energy = 0.55
	sun.shadow_enabled = true
	add_child(sun)
	activate_scenery(0)
	camera = Camera3D.new()
	add_child(camera)
	camera.current = true
	view_rig = BattleCamera.new(camera)
	view_rig.set_mode(1,Vector3.ZERO,true)
	var theme := Theme.new()
	theme.default_font = load("res://assets/chinese.otf")
	ThemeDB.fallback_font = theme.default_font
	ui = CanvasLayer.new()
	add_child(ui)
	for rect in [Rect2(16,16,850,78),Rect2(16,700,1030,80)]:
		var plate := ColorRect.new()
		plate.position = rect.position
		plate.size = rect.size
		plate.color = Color(0.03,0.07,0.11,0.8)
		plate.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ui.add_child(plate)
	hud = label(ui,"",Vector2(32,24),23)
	status = label(ui,"",Vector2(32,710),18)
	hp_bar = ProgressBar.new()
	hp_bar.position = Vector2(32,65)
	hp_bar.size = Vector2(290,15)
	hp_bar.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color("35d497")
	fill.set_corner_radius_all(4)
	hp_bar.add_theme_stylebox_override("fill",fill)
	ui.add_child(hp_bar)
	stage_hud = label(ui,"",Vector2(32,108),23)
	stage_hud.add_theme_constant_override("outline_size",6)
	stage_hud.add_theme_color_override("font_outline_color",Color("182a28"))
	banner = label(ui,"",Vector2(420,180),34)
	banner.add_theme_constant_override("outline_size",8)
	banner.add_theme_color_override("font_outline_color",Color("0e1c28"))
	banner_hint = label(ui,"",Vector2(420,227),18)
	banner_hint.add_theme_constant_override("outline_size",5)
	for i in range(3):
		var skill_button := Button.new()
		skill_button.position = Vector2(1060,568+i*72)
		skill_button.size = Vector2(200,62)
		skill_button.focus_mode = Control.FOCUS_NONE
		skill_button.add_theme_font_size_override("font_size",17)
		skill_button.pressed.connect(skill.bind(i))
		ui.add_child(skill_button)
		skill_buttons.append(skill_button)
	view_button = Button.new()
	view_button.position = Vector2(880,22)
	view_button.size = Vector2(260,48)
	view_button.focus_mode = Control.FOCUS_NONE
	view_button.add_theme_font_size_override("font_size",18)
	view_button.pressed.connect(cycle_view)
	ui.add_child(view_button)
	var reset_button := Button.new()
	reset_button.text = "R 复位"
	reset_button.position = Vector2(1155,22)
	reset_button.size = Vector2(105,48)
	reset_button.focus_mode = Control.FOCUS_NONE
	reset_button.pressed.connect(reset_view)
	ui.add_child(reset_button)
	view_hint = label(ui,"1 俯视 / 2 斜视 / 3 跟随\n右键拖动旋转 · 滚轮缩放",Vector2(885,80),15)
	view_hint.add_theme_constant_override("outline_size",4)
	view_controls = [view_button,reset_button,view_hint]
	update_view_ui()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = 22050
	gen.buffer_length = 0.12
	sound = AudioStreamPlayer.new()
	sound.stream = gen
	add_child(sound)
	if not auto_test:
		sound.play()
		synth = sound.get_stream_playback()
	show_menu()
	menu_preview = "--menu-preview" in OS.get_cmdline_user_args() or "--back-preview" in OS.get_cmdline_user_args()
	if "--back-preview" in OS.get_cmdline_user_args():
		for model in portrait_rigs:
			model.rotation.y = PI
	preview = "--preview" in OS.get_cmdline_user_args()
	if preview:
		start_game(0)
		for i in range(16):
			var e := spawn_enemy(i%4)
			e.node.position = Vector3(cos(i*TAU/16.0)*8,0,sin(i*TAU/16.0)*8)
	for i in range(3):
		if ("--combat-preview="+str(i)) in OS.get_cmdline_user_args():
			combat_preview = i
	if combat_preview>=0:
		start_game(combat_preview)
		attack_clock = 100
		for i in range(10):
			var e := spawn_enemy(2)
			e.node.position = Vector3(cos(i*TAU/10)*4.0,0,sin(i*TAU/10)*4.0)
			e.cooldown = 100
		spawn_clock = 100
		var target := spawn_enemy(2)
		target.node.position = Vector3(2,0,-2)
		target.cooldown = 100
		perform_attack(target)
		skill(0)
	zombie_preview = "--zombie-preview" in OS.get_cmdline_user_args() or "--zombie-back-preview" in OS.get_cmdline_user_args()
	if zombie_preview:
		show_zombie_gallery()
		if "--zombie-back-preview" in OS.get_cmdline_user_args():
			for model in portrait_rigs:
				model.rotation.y = PI
	combat_demo = "--combat-demo" in OS.get_cmdline_user_args()
	camera_demo = "--camera-demo" in OS.get_cmdline_user_args()
	for i in range(3):
		if ("--camera-preview="+str(i)) in OS.get_cmdline_user_args():
			camera_preview = i
	if camera_preview>=0:
		setup_camera_scene(camera_preview)
	stage_demo = "--stage-demo" in OS.get_cmdline_user_args()
	for i in range(3):
		if ("--stage-preview="+str(i)) in OS.get_cmdline_user_args():
			stage_preview = i
	if stage_preview>=0:
		setup_stage_preview(stage_preview)
	ultimate_demo = "--ultimate-demo" in OS.get_cmdline_user_args()
	for i in range(3):
		if ("--skill-preview="+str(i)) in OS.get_cmdline_user_args(): skill_preview = i
	if skill_preview>=0: setup_ultimate_preview(skill_preview)
	for i in range(3):
		if ("--circle-preview="+str(i)) in OS.get_cmdline_user_args(): circle_preview = i
	if circle_preview>=0:
		start_game(0)
		begin_stage(circle_preview)
		circle.animate(3,10)
		circle.set_health(circle_target.hp,EnergyCircle.HEALTH[circle_preview])
		player.hide()
		ui.hide()
		camera.position = Vector3(6,5.5,7)
		camera.look_at(Vector3(0,1.1,0))
		playing = false
	for i in range(3):
		if ("--enemy-preview="+str(i)) in OS.get_cmdline_user_args(): enemy_preview = i
	if enemy_preview>=0:
		gallery_stage = enemy_preview
		show_zombie_gallery()
	ending_preview = "--ending-preview" in OS.get_cmdline_user_args()
	if ending_preview:
		start_game(0)
		begin_stage(2)
		finish(true)
		ending.advance(3.0)
		ending.next_line()
		ending.next_line()
	if auto_test:
		start_game(0)

func label(parent: Node, text: String, pos: Vector2, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.add_theme_font_size_override("font_size",size)
	l.add_theme_color_override("font_color",Color("e5edf7"))
	parent.add_child(l)
	return l

func panel(title: String, subtitle: String) -> VBoxContainer:
	view_drag = false
	banner_time = 0
	banner.modulate.a = 0
	banner_hint.modulate.a = 0
	if is_instance_valid(stage_hud): stage_hud.hide()
	for control in view_controls:
		control.hide()
	portrait_rigs.clear()
	if is_instance_valid(menu):
		menu.queue_free()
	menu = ColorRect.new()
	menu.color = Color(0.025,0.045,0.08,0.94)
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(menu)
	var col := VBoxContainer.new()
	col.position = Vector2(180,140)
	col.custom_minimum_size = Vector2(920,0)
	col.add_theme_constant_override("separation",18)
	menu.add_child(col)
	var heading := Label.new()
	heading.text = title
	heading.add_theme_font_size_override("font_size",48)
	col.add_child(heading)
	var sub := Label.new()
	sub.text = subtitle
	sub.add_theme_font_size_override("font_size",18)
	col.add_child(sub)
	return col

func button(parent: Node, text: String, callback: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(920,64)
	b.add_theme_font_size_override("font_size",19)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("173144")
	style.border_color = Color("367765")
	style.set_border_width_all(1)
	style.set_corner_radius_all(8)
	b.add_theme_stylebox_override("normal",style)
	var hover := style.duplicate() as StyleBoxFlat
	hover.bg_color = Color("265846")
	b.add_theme_stylebox_override("hover",hover)
	b.pressed.connect(callback)
	parent.add_child(b)

func show_menu() -> void:
	clear_ending()
	click_path.clear()
	playing = false
	paused = false
	choosing = false
	var col := panel("积木 / 远征", "非洲草原 → 埃及金字塔 → 中国长城 · 选择英雄出战")
	col.position = Vector2(60,28)
	col.custom_minimum_size = Vector2(1160,0)
	col.add_theme_constant_override("separation",12)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",16)
	col.add_child(row)
	var descriptions := ["Q 青龙横扫 · 半径 6\nE 破阵突击 · 位移免伤\nF 绝气斩 · 龙形剑气", "Q 爆裂弹 · 半径 10\nE 火力全开 · 持续 8 秒\nF 火球天降 · 180 伤害", "Q 冰霜新星 · 半径 8\nE 极寒爆发 · 半径 10\nF 四方霜降 · 持续冰箭"]
	for i in range(3):
		var card := PanelContainer.new()
		card.custom_minimum_size = Vector2(376,0)
		var style := StyleBoxFlat.new()
		style.bg_color = Color("101f30")
		style.border_color = HeroVisual.PALETTES[i].trim.darkened(0.15)
		style.set_border_width_all(1)
		style.set_corner_radius_all(10)
		style.content_margin_left = 12
		style.content_margin_right = 12
		style.content_margin_top = 10
		style.content_margin_bottom = 12
		card.add_theme_stylebox_override("panel",style)
		row.add_child(card)
		var body := VBoxContainer.new()
		body.add_theme_constant_override("separation",9)
		card.add_child(body)
		make_portrait(body,i)
		for entry in [[HEROES[i].name,26],[HEROES[i].role,16],[descriptions[i],17]]:
			var text := Label.new()
			text.text = entry[0]
			text.add_theme_font_size_override("font_size",entry[1])
			text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			body.add_child(text)
		button(body,"选择出战",start_game.bind(i))
		body.get_child(body.get_child_count()-1).custom_minimum_size = Vector2(352,50)
	var tip := Label.new()
	tip.text = "鼠标左键点地移动 / WASD / 方向键    Q / E / F 技能    空格闪避    Esc 暂停\n三关连续挑战 · 击败十名敌人使法阵落地，击破法阵后晋级 · 等级与强化继承\n1/2/3 视角 · V 切换 · 右键旋转 · 滚轮缩放 · R 复位"
	tip.add_theme_font_size_override("font_size",17)
	col.add_child(tip)
	var build_label := Label.new()
	var build_stamp := "开发源码"
	if FileAccess.file_exists("res://assets/build-info.json"):
		var metadata: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://assets/build-info.json"))
		if metadata is Dictionary: build_stamp = str(metadata.get("runtime_sha256","")).substr(0,8)
	build_label.text = "v%s · 构建 %s" % [ProjectSettings.get_setting("application/config/version","dev"),build_stamp]
	build_label.position = Vector2(900,745)
	build_label.add_theme_font_size_override("font_size",16)
	menu.add_child(build_label)
	var catalog := Button.new()
	catalog.text = "远征敌人图鉴"
	catalog.position = Vector2(1000,50)
	catalog.size = Vector2(210,46)
	catalog.add_theme_font_size_override("font_size",20)
	catalog.pressed.connect(show_zombie_gallery)
	menu.add_child(catalog)
	difficulty_picker = OptionButton.new()
	difficulty_picker.position = Vector2(910,104)
	difficulty_picker.size = Vector2(300,35)
	for title in ["简单 · 敌人三项降低 20%","普通 · 标准挑战","困难 · 分关强化敌人"]:
		difficulty_picker.add_item(title)
	difficulty_picker.select(difficulty)
	difficulty_picker.item_selected.connect(func(index: int): difficulty = index)
	difficulty_picker.tooltip_text = "简单：血量、速度、伤害 ×0.8\n普通：原有数值\n困难：第一关血量与速度 ×1.10，伤害不变；第二关三项 ×1.15；第三关三项 ×1.20"
	menu.add_child(difficulty_picker)

func show_zombie_gallery() -> void:
	playing = false
	paused = false
	choosing = false
	var col := panel(Campaign.TITLES[gallery_stage]+" · 敌人图鉴", "拖动可旋转模型 · 当前难度：%s" % Campaign.DIFFICULTIES[difficulty])
	col.position = Vector2(60,28)
	col.custom_minimum_size = Vector2(1160,0)
	col.add_theme_constant_override("separation",12)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation",12)
	col.add_child(row)
	var names: Array = Campaign.ENEMY_NAMES[gallery_stage]
	var descriptions: Array = [
		["近战挥爪", "快速近战扑击", "直线飞箭", "绿色小蛇 · 直线", "远程火球 · 近战爪击", "锁定方向 · 犀角冲撞"],
		["近战利爪", "快速近战扑击", "直线飞箭", "蛇咒 · 直线小蛇", "火球与利爪", "蓄力冲撞"],
		["陶土面孔 · 扎甲长兵", "轻装陶俑 · 快步追击", "层叠重甲 · 持盾守卫", "陶土弩手 · 远程弩箭", "将军冠盔 · 雄关首领", "投掷汉堡形状石弹"]
	][gallery_stage]
	for i in range(names.size()):
		var card := PanelContainer.new()
		card.custom_minimum_size = Vector2(181,0)
		var style := StyleBoxFlat.new()
		style.bg_color = Color("111f28")
		style.border_color = Campaign.COLORS[gallery_stage].darkened(0.3)
		style.set_border_width_all(1)
		style.set_corner_radius_all(8)
		style.content_margin_left = 12
		style.content_margin_right = 12
		style.content_margin_top = 10
		style.content_margin_bottom = 12
		card.add_theme_stylebox_override("panel",style)
		row.add_child(card)
		var body := VBoxContainer.new()
		body.add_theme_constant_override("separation",9)
		card.add_child(body)
		make_portrait(body,i,true)
		var data := Campaign.stats(gallery_stage,i,ENEMIES[i],difficulty)
		var stats := "血量 %.1f / 伤害 %.1f\n体型 ×%.1f" % [data.hp,data.damage,data.scale]
		for entry in [[names[i],22],[stats,16],[descriptions[i],14]]:
			var text := Label.new()
			text.text = entry[0]
			text.add_theme_font_size_override("font_size",entry[1])
			text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			body.add_child(text)
	var next := Button.new()
	next.text = "切换图鉴："+Campaign.TITLES[(gallery_stage+1)%3]
	next.position = Vector2(890,47)
	next.size = Vector2(325,45)
	next.pressed.connect(func():
		gallery_stage = (gallery_stage+1)%3
		show_zombie_gallery()
	)
	menu.add_child(next)
	button(col,"返回英雄选择",show_menu)

func make_portrait(parent: Control, index: int, is_zombie := false) -> void:
	var holder := SubViewportContainer.new()
	holder.custom_minimum_size = Vector2(157,285) if is_zombie else Vector2(352,265)
	holder.stretch = true
	holder.mouse_default_cursor_shape = Control.CURSOR_DRAG
	parent.add_child(holder)
	var viewport := SubViewport.new()
	viewport.size = Vector2i(holder.custom_minimum_size)
	viewport.own_world_3d = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.msaa_3d = Viewport.MSAA_2X
	holder.add_child(viewport)
	var environment := WorldEnvironment.new()
	environment.environment = Environment.new()
	environment.environment.background_mode = Environment.BG_COLOR
	environment.environment.background_color = Color("101f30")
	environment.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.environment.ambient_light_color = Color("d3e1f2")
	environment.environment.ambient_light_energy = 0.65
	viewport.add_child(environment)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-30,-35,0)
	key.light_color = Color("ffebc4")
	key.light_energy = 1.25
	viewport.add_child(key)
	var fill := OmniLight3D.new()
	fill.position = Vector3(-2,3,-3)
	fill.light_color = Color("9ecbff")
	fill.light_energy = 0.85
	fill.omni_range = 8
	viewport.add_child(fill)
	var rim := OmniLight3D.new()
	rim.position = Vector3(1,3,2)
	rim.light_color = Campaign.COLORS[gallery_stage] if is_zombie else HeroVisual.PALETTES[index].energy
	rim.light_energy = 1.0
	rim.omni_range = 7
	viewport.add_child(rim)
	var stage := MeshInstance3D.new()
	var disc := CylinderMesh.new()
	disc.top_radius = 1.15
	disc.bottom_radius = 1.23
	disc.height = 0.12
	disc.radial_segments = 48
	stage.mesh = disc
	stage.position.y = -0.08
	stage.material_override = HeroVisual.mat(Color("26354b"))
	viewport.add_child(stage)
	var model: Node3D = CampaignEnemy.new() if is_zombie else HeroVisual.new()
	if is_zombie:
		model.build_for_stage(gallery_stage,index)
	else:
		model.build(index)
	model.rotation.y = -0.1
	viewport.add_child(model)
	portrait_rigs.append(model)
	var cam := Camera3D.new()
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = 5.5 if is_zombie and gallery_stage==2 and index==5 else 3.9 if is_zombie else 3.85
	cam.position = Vector3(2.3,2.6,-5)
	viewport.add_child(cam)
	cam.look_at(Vector3(0,1.1 if is_zombie and gallery_stage==0 else 1.43,0))
	cam.current = true
	holder.gui_input.connect(func(event: InputEvent):
		if event is InputEventMouseMotion and event.button_mask & MOUSE_BUTTON_MASK_LEFT:
			model.rotation.y += event.relative.x*0.015
	)

func start_game(index: int) -> void:
	clear_ending()
	fx.clear()
	shots.clear()
	swings.clear()
	banner_time = 0
	banner.text = ""
	banner_hint.text = ""
	shake_strength = 0
	portrait_rigs.clear()
	if is_instance_valid(menu):
		menu.queue_free()
	for e in enemies:
		e.node.queue_free()
	enemies.clear()
	for b in bullets:
		if b.has("marker"): b.marker.queue_free()
		b.node.queue_free()
	bullets.clear()
	if is_instance_valid(player):
		player.queue_free()
	hero = index
	armor_bonus = 0
	max_hp = HEROES[hero].hp
	hp = max_hp
	elapsed = 0
	kills = 0
	xp = 0
	level = 1
	damage_mult = 1
	spawn_clock = 0
	attack_clock = 0
	q_clock = 0
	e_clock = 0
	buff = 0
	invuln = 0
	dash_clock = 0
	boss_spawned = false
	campaign_won = false
	between_stages = false
	choosing = false
	paused = false
	player = HeroVisual.new()
	player.build(hero)
	world.add_child(player)
	var halo := MeshInstance3D.new()
	var torus := TorusMesh.new()
	torus.inner_radius = 0.57
	torus.outer_radius = 0.63
	torus.rings = 24
	torus.ring_segments = 6
	halo.mesh = torus
	halo.position.y = 0.035
	halo.material_override = HeroVisual.mat(HEROES[hero].color,false,true)
	player.add_child(halo)
	begin_stage(0)

func activate_scenery(index: int) -> void:
	for scene in stage_scenes:
		if is_instance_valid(scene): scene.hide()
	if not is_instance_valid(stage_scenes[index]):
		var scene := StageWorld.new()
		scene.build(index)
		world.add_child(scene)
		stage_scenes[index] = scene
	stage_scenes[index].show()
	var sky_material: ProceduralSkyMaterial = sky.sky.sky_material
	sky_material.sky_top_color = [Color("7baaba"),Color("87adbd"),Color("779baa")][index]
	sky_material.sky_horizon_color = Campaign.SKY[index]
	sky_material.ground_horizon_color = Campaign.SKY[index]
	sky_material.ground_bottom_color = [Color("a18c61"),Color("bc9d6c"),Color("687c6e")][index]
	sky.ambient_light_color = [Color("ffebc3"),Color("ffedcc"),Color("d1e4e3")][index]
	if is_instance_valid(sunlight):
		sunlight.light_color = [Color("ffe1a2"),Color("fff0cd"),Color("e4f3f0")][index]

func clear_battle() -> void:
	click_path.clear()
	if is_instance_valid(circle):
		circle.hide()
		circle.queue_free()
	circle = null
	if not circle_target.is_empty(): circle_target.dead = true
	circle_target = {}
	for e in enemies:
		e.node.hide()
		e.node.queue_free()
	enemies.clear()
	for b in bullets:
		if b.has("marker"): b.marker.queue_free()
		b.node.hide()
		b.node.queue_free()
	bullets.clear()
	shots.clear()
	swings.clear()
	ultimate_jobs.clear()
	frost_age = -1
	frost_pulses = 0
	fx.clear()
	shake_strength = 0

func begin_stage(index: int) -> void:
	clear_battle()
	stage_index = clampi(index,0,2)
	wave_index = 0
	wave_spawned = 0
	stage_spawned = 0
	stage_kills = 0
	stage_cleared = false
	circle_destroyed = false
	circle = EnergyCircle.new()
	circle.build(stage_index)
	world.add_child(circle)
	circle_target = {"node":circle,"hp":EnergyCircle.HEALTH[stage_index],"dead":false,"circle":true,"slow":0.0}
	between_stages = false
	boss_spawned = false
	choosing = false
	paused = false
	activate_scenery(stage_index)
	player.position = Vector3.ZERO
	player.rotation = Vector3.ZERO
	max_hp = HEROES[hero].stage_hp[stage_index]+armor_bonus
	hp = max_hp
	q_clock = 0
	e_clock = 0
	w_clock = 0
	dash_clock = 0
	attack_clock = 0.4
	invuln = 1.5
	buff = 0
	spawn_clock = 2.0
	playing = true
	direction = Vector3.FORWARD
	view_drag = false
	view_rig.recenter(player.position,true)
	update_view_ui()
	announce("第 %d 关 · %s" % [stage_index+1,Campaign.TITLES[stage_index]],"击败十名敌人使法阵落地，再将其击破",Campaign.COLORS[stage_index])
	banner_time = 3.0

func update_campaign_spawns(delta: float) -> void:
	if stage_cleared or circle_destroyed: return
	spawn_clock -= delta
	if spawn_clock>0 or enemies.filter(func(e): return not e.get("dead",false)).size()>=12: return
	var queue: Array = Campaign.WAVES[stage_index][wave_index]
	var kind: int = queue[wave_spawned]
	spawn_enemy(kind)
	wave_spawned += 1
	stage_spawned += 1
	if kind==4: boss_spawned = true
	if wave_spawned>=queue.size():
		wave_spawned = 0
		wave_index = (wave_index+1)%3
	spawn_clock = 1.25

func check_wave_clear() -> void:
	if stage_cleared or not playing or choosing or not circle_destroyed: return
	stage_cleared = true
	clear_battle()
	if stage_index==2:
		finish(true)
	else:
		between_stages = true
		choosing = true
		var col := panel("%s · 法阵已击破" % Campaign.TITLES[stage_index],"法阵崩解，敌军消散 · 选择强化后前往 %s\n保留等级与强化，恢复全部血量并刷新技能。" % Campaign.TITLES[stage_index+1])
		button(col,"强化攻击 +20%   →   进入下一关",upgrade.bind(0))
		button(col,"强化装甲 +40 血量上限   →   进入下一关",upgrade.bind(1))
		button(col,"战地补给 +10% 伤害   →   进入下一关",travel_supply)

func attack_targets() -> Array:
	var targets := enemies.duplicate()
	if is_instance_valid(circle) and circle.landed and not circle_destroyed and not circle_target.is_empty():
		targets.append(circle_target)
	return targets

func hurt_circle(amount: float, from_skill: bool) -> void:
	if not is_instance_valid(circle) or not circle.landed or circle_destroyed: return
	var damage := amount*(0.5 if from_skill else 1.0)
	circle_target.hp = maxf(0,circle_target.hp-damage)
	circle.set_health(circle_target.hp,EnergyCircle.HEALTH[stage_index])
	fx.impact(Vector3(0,1,0),circle.tint,true)
	fx.number(Vector3(0,2,0),damage,Color.WHITE,true)
	if circle_target.hp<=0:
		circle_destroyed = true
		circle_target.dead = true
		circle.hide()
		# Resolve the transition after all attack/projectile iterations have finished.
		for e in enemies:
			e.dead = true
			e.node.hide()
			e.node.queue_free()
		announce("能量法阵已击破","敌军消散 · 本关净化完成",circle.tint)

func travel_supply() -> void:
	if not between_stages: return
	damage_mult += 0.1
	upgrade(2)

func setup_stage_preview(index: int) -> void:
	start_game(0)
	begin_stage(index)
	spawn_clock = 100
	attack_clock = 100
	var positions := [Vector3(-3,0,-3),Vector3(-5,0,-6),Vector3(3,0,-4),Vector3(5,0,-6),Vector3(0,0,-9)]
	for i in range(5):
		var e := spawn_enemy(i)
		e.node.position = positions[i]
		e.cooldown = 100
	view_rig.set_mode(1,player.position,true)
	view_rig.pitch = deg_to_rad(25)
	view_rig.update(player.position,0,true)
	update_view_ui()
	if stage_preview>=0: banner_time = 0

func spawn_enemy(kind: int) -> Dictionary:
	var data := Campaign.stats(stage_index,kind,ENEMIES[kind],difficulty)
	var node := CampaignEnemy.new()
	node.build_for_stage(stage_index,kind,randi_range(0,2))
	node.phase = randf()*TAU
	node.animate(0,false)
	node.scale = Vector3.ONE*data.scale
	var angle := randf()*TAU
	node.position = Vector3(cos(angle)*2.5,0,sin(angle)*2.5)
	node.position.x = clampf(node.position.x,-21,21)
	node.position.z = clampf(node.position.z,-21,21)
	world.add_child(node)
	if is_instance_valid(circle):
		fx.bolt(circle.position+Vector3(0,1.8,0),node.position+Vector3(0,0.5,0),circle.tint,0.35)
	var health_bar := MeshInstance3D.new()
	var health_quad := QuadMesh.new()
	health_quad.size = Vector2(0.8,0.09)
	health_bar.mesh = health_quad
	health_bar.position = Vector3(0,node.health_height,0)
	var health_material := material(Color("e36b7e"))
	health_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	health_material.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	health_bar.material_override = health_material
	health_bar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	node.add_child(health_bar)
	var e := {"node":node,"bar":health_bar,"kind":kind,"hp":data.hp,"data":data,"cooldown":1.0,"slow":0.0,"flash":0.0}
	enemies.append(e)
	return e

func tone(freq: float) -> void:
	if synth == null:
		return
	var count := mini(synth.get_frames_available(),1600)
	for i in range(count):
		var sample := sin(TAU*freq*i/22050.0)*0.12*(1.0-float(i)/count)
		synth.push_frame(Vector2(sample,sample))

func ring(pos: Vector3, radius: float, color: Color) -> void:
	fx.wave(pos,radius,color,0.4)

func flash_enemy(e: Dictionary) -> void:
	e.flash = 0.12
	e.node.set_overlay(white_flash)

func hurt(e: Dictionary, amount: float, heavy := false, frost := false, from_skill := false) -> void:
	if e.get("circle",false):
		hurt_circle(amount,from_skill)
		return
	if e.get("dead",false):
		return
	var pos: Vector3 = e.node.position
	e.hp -= amount
	if e.hp<0.00001: e.hp = 0
	e.bar.scale.x = maxf(0,e.hp/e.data.hp)
	flash_enemy(e)
	fx.impact(pos,Color("9deeff") if frost else HEROES[hero].color,heavy)
	fx.number(pos,amount,Color("fff0a9") if heavy else Color("bcefff") if frost else Color.WHITE,heavy)
	if e.hp<=0:
		e.dead = true
		kills += 1
		stage_kills += 1
		xp += 1 if e.kind!=4 else 20
		fx.shards(pos,e.data.color)
		e.node.queue_free()

func perform_attack(target: Dictionary) -> void:
	if target.get("dead",false):
		return
	var aim := Vector3(target.node.position.x,0,target.node.position.z)
	if player.position.distance_to(aim)>0.01: player.look_at(aim)
	player.attack()
	if hero==0:
		swings.append({"delay":0.10,"damage":HEROES[hero].damage*damage_mult})
	else:
		var start: Vector3 = player.emission_point()
		var end: Vector3 = target.node.position+Vector3(0,1.15,0)
		var duration := clampf(start.distance_to(end)/(24.0 if hero==1 else 14.0),0.12 if hero==1 else 0.15,0.8)
		var color := Color("ffd46d") if hero==1 else Color("83e6ff")
		var forward := (end-start).normalized()
		fx.muzzle(start,forward,color,buff>0)
		var visual: Dictionary = fx.bolt(start,end,color,duration,hero==2)
		shots.append({"target":target,"end":end,"elapsed":0.0,"duration":duration,"damage":HEROES[hero].damage*damage_mult,"frost":hero==2,"visual":visual})
	tone(240 if hero==0 else 660 if hero==1 else 880)

func update_swings(delta: float) -> void:
	for i in range(swings.size()-1,-1,-1):
		var swing: Dictionary = swings[i]
		swing.delay -= delta
		if swing.delay<=0:
			fx.slash(player.position,player.rotation.y,3.5,HEROES[0].color)
			fx.wave(player.position,3.5,HEROES[0].color,0.25,0.8)
			for e in attack_targets():
				if not e.get("dead",false) and e.node.position.distance_to(player.position)<3.5:
					hurt(e,swing.damage)
			swings.remove_at(i)

func update_shots(delta: float) -> void:
	for i in range(shots.size()-1,-1,-1):
		var shot: Dictionary = shots[i]
		shot.elapsed += delta
		var target: Dictionary = shot.target
		if not target.get("dead",false):
			shot.end = target.node.position+Vector3(0,1.15,0)
		shot.visual.end = shot.end
		if shot.elapsed>=shot.duration:
			if not target.get("dead",false):
				if shot.frost:
					target.slow = maxf(target.slow,1.0)
					fx.shards(target.node.position,Color("a5eeff"),3,true)
				hurt(target,shot.damage,false,shot.frost)
			shots.remove_at(i)

func announce(title: String, detail: String, color: Color) -> void:
	banner.text = title
	banner_hint.text = detail
	banner.modulate = color.lightened(0.3)
	banner_hint.modulate = Color.WHITE
	banner_time = 1.4

func damage_player(amount: float) -> void:
	if invuln > 0 or not playing:
		return
	hp -= amount
	shake_strength = maxf(shake_strength,0.08)
	invuln = 0.5
	ring(player.position,0.8,Color("ff4a65"))
	tone(120)
	if hp <= 0:
		finish(false)

func area_damage(radius: float, amount: float, slow := false, heavy := true) -> void:
	for e in attack_targets():
		if not e.get("dead",false) and e.node.position.distance_to(player.position)<=radius:
			if slow:
				e.slow = maxf(e.slow,3.0)
			hurt(e,amount*damage_mult,heavy,slow,true)

func skill(which: int) -> void:
	if not playing or choosing or which<0 or which>2: return
	var remaining := skill_cooldown(which)
	if remaining>0:
		announce("技能冷却中","还需 %.1f 秒" % remaining,Color("c6d2de"))
		return
	var color: Color = HEROES[hero].color
	if which==0:
		q_clock = HEROES[hero].q
		var radius: float = HEROES[hero].q_radius
		if hero==0:
			fx.slash(player.position,player.rotation.y,radius,color,true)
			fx.wave(player.position,radius,color,0.65)
			announce("Q · 青龙横扫","半径 6 · 70 范围伤害",color)
		elif hero==1:
			fx.explosion(player.position,radius)
			announce("Q · 爆裂弹","半径 10 · 75 范围伤害",Color("ffc677"))
		else:
			fx.frost_field(player.position,radius)
			announce("Q · 冰霜新星","半径 8 · 45 伤害 · 减速 3 秒",color)
		area_damage(radius,HEROES[hero].q_damage,hero==2)
	elif which==1:
		e_clock = HEROES[hero].e
		if hero==0:
			invuln = 1.0
			var before := player.position
			player.position += direction*6
			player.position.x = clampf(player.position.x,-21,21)
			player.position.z = clampf(player.position.z,-21,21)
			fx.charge(before,player.position,color)
			fx.slash(player.position,player.rotation.y,5.0,color,true)
			area_damage(5,120)
			announce("E · 破阵突击","突进残影 · 120 伤害 · 免伤 1 秒",color)
		elif hero==1:
			buff = 8
			fx.aura(player,Color("ff9a47"),8.0)
			fx.wave(player.position,2.0,Color("ffd97c"),0.6)
			announce("E · 火力全开","攻击间隔缩短 40% · 持续 8 秒",Color("ffc677"))
		else:
			fx.frost_field(player.position,10.0,true)
			area_damage(10,120,true)
			announce("E · 极寒爆发","半径 10 · 120 伤害 · 减速 3 秒",color)
	else:
		w_clock = THIRD_COOLDOWN
		cast_third_skill()
		attack_clock = maxf(attack_clock,0.4)
	player.cast(which)
	shake_strength = maxf(shake_strength,0.12 if which==0 else 0.18 if which==1 else 0.25)
	tone(180+hero*170+which*70)

func skill_cooldown(which: int) -> float:
	return q_clock if which==0 else e_clock if which==1 else w_clock

func in_line(point: Vector3, origin: Vector3, heading: Vector3, length: float, half_width: float) -> bool:
	var offset := point-origin
	offset.y = 0
	var along := offset.dot(heading)
	return along>=0 and along<=length and (offset-heading*along).length()<=half_width

func cast_third_skill() -> void:
	var origin := player.position
	var heading := -player.global_basis.z
	heading.y = 0
	heading = heading.normalized()
	if hero==0:
		fx.dragon_cut(origin,heading,DRAGON_RANGE)
		for e in attack_targets():
			if not e.get("dead",false) and in_line(e.node.position,origin,heading,DRAGON_RANGE,DRAGON_HALF_WIDTH):
				hurt(e,EnergyCircle.HEALTH[stage_index]*damage_mult if e.get("circle",false) else maxf(e.hp,1),true,false,true)
		announce("F · 绝气斩","大刀下斩 · 前方龙形剑气直线清敌",HEROES[0].color)
	elif hero==1:
		fx.meteor_rain(origin,10.0,0.65)
		ultimate_jobs.append({"mode":"meteor","delay":0.65,"origin":origin,"damage":180.0*damage_mult})
		announce("F · 火球天降","半径 10 · 火球落地造成 180 伤害",Color("ffbc68"))
	else:
		frost_age = 0
		frost_pulses = 0
		frost_heading = heading
		fx.frost_field(origin,FROST_RADIUS)
		fx.aura(player,Color("84dcff"),3.0)
		emit_frost_pulse()
		announce("F · 四方霜降","四向冰箭 · 持续 3 秒 · 总伤害 200",HEROES[2].color)

func emit_frost_pulse() -> void:
	var origin := player.position
	for i in range(4):
		var heading := frost_heading.rotated(Vector3.UP,i*PI/2)
		fx.bolt(origin+Vector3(0,1.2,0)+heading*0.6,origin+Vector3(0,1.2,0)+heading*FROST_RADIUS,Color("97ecff"),0.18,true)
	ultimate_jobs.append({"mode":"frost","delay":0.18,"origin":origin,"heading":frost_heading,"damage":(floorf(200.0*(frost_pulses+1)/FROST_PULSES)-floorf(200.0*frost_pulses/FROST_PULSES))*damage_mult})
	frost_pulses += 1

func update_third_skills(delta: float) -> void:
	for i in range(ultimate_jobs.size()-1,-1,-1):
		var job: Dictionary = ultimate_jobs[i]
		job.delay -= delta
		if job.delay>0: continue
		if job.mode=="meteor":
			fx.explosion(job.origin,10.0)
			for n in range(13):
				var angle := n*2.39996
				var radius := sqrt(float(n)/12)*9.0
				fx.impact(job.origin+Vector3(sin(angle)*radius,0,cos(angle)*radius),Color("ffb669"),true)
			for e in attack_targets():
				if not e.get("dead",false) and e.node.position.distance_to(job.origin)<=10.0:
					hurt(e,job.damage,true,false,true)
		else:
			for e in attack_targets():
				if e.get("dead",false) or e.node.position.distance_to(job.origin)>FROST_RADIUS: continue
				var hit := false
				for side in range(4):
					hit = hit or in_line(e.node.position,job.origin,job.heading.rotated(Vector3.UP,side*PI/2),FROST_RADIUS,FROST_HALF_WIDTH)
				if hit: hurt(e,job.damage,false,true,true)
		ultimate_jobs.remove_at(i)
	if frost_age>=0:
		frost_age += delta
		while frost_pulses<FROST_PULSES and frost_age+0.00001>=frost_pulses*0.25:
			emit_frost_pulse()
		if frost_age>=3.0: frost_age = -1

func update_view_ui() -> void:
	stage_hud.visible = playing and not choosing
	view_button.text = "V · %s  %d/3" % [BattleCamera.NAMES[view_rig.mode],view_rig.mode+1]
	for control in view_controls:
		control.visible = playing and not choosing

func set_view(index: int) -> void:
	if not playing or choosing:
		return
	view_rig.set_mode(index,player.position)
	update_view_ui()

func cycle_view() -> void:
	set_view(view_rig.mode+1)

func reset_view() -> void:
	if not playing or choosing:
		return
	view_rig.recenter(player.position)
	update_view_ui()

func update_camera_occlusion() -> void:
	for e in enemies:
		if not e.get("dead",false):
			e.node.set_camera_occluded(view_rig.blocks_player(e.node.position,e.data.scale,player.position))

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_RIGHT and not event.pressed:
		view_drag = false
	if not playing or choosing:
		view_drag = false
		return
	if event is InputEventMouseMotion and view_drag:
		view_rig.orbit(event.relative)
		get_viewport().set_input_as_handled()

func _unhandled_input(event: InputEvent) -> void:
	if not playing or choosing or not event is InputEventMouseButton:
		return
	if event.button_index==MOUSE_BUTTON_LEFT and event.pressed:
		var point: Variant = ClickNavigation.ground_point(camera,event.position)
		if point is Vector3:
			set_click_destination(point)
		get_viewport().set_input_as_handled()
	elif event.button_index==MOUSE_BUTTON_RIGHT and event.pressed:
		view_drag = true
		get_viewport().set_input_as_handled()
	elif event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:
		view_rig.zoom(-1 if event.button_index==MOUSE_BUTTON_WHEEL_UP else 1)
		get_viewport().set_input_as_handled()

func _unhandled_key_input(event: InputEvent) -> void:
	if is_instance_valid(ending):
		if event is InputEventKey and event.pressed and not event.echo:
			if event.keycode in [KEY_ENTER,KEY_SPACE]: ending.next_line()
			elif event.keycode==KEY_ESCAPE: ending.finish_scene()
			get_viewport().set_input_as_handled()
		return
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode == KEY_ESCAPE and not choosing and is_instance_valid(player):
		if playing:
			playing = false
			var col := panel("已暂停", "调整呼吸，再战尸潮。")
			paused = true
			button(col,"继续战斗",resume_game)
			button(col,"返回选人",show_menu)
		elif paused:
			resume_game()
		return
	if not playing or choosing:
		return
	if event.physical_keycode in [KEY_W,KEY_A,KEY_S,KEY_D,KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT] or event.keycode in [KEY_W,KEY_A,KEY_S,KEY_D,KEY_UP,KEY_DOWN,KEY_LEFT,KEY_RIGHT]:
		click_path.clear()
	if event.keycode in [KEY_1,KEY_2,KEY_3]:
		set_view(event.keycode-KEY_1)
		return
	if event.keycode==KEY_V:
		cycle_view()
		return
	if event.keycode==KEY_R:
		reset_view()
		return
	if event.keycode == KEY_Q:
		skill(0)
	if event.keycode == KEY_E:
		skill(1)
	if event.keycode == KEY_F:
		skill(2)
	if event.keycode == KEY_SPACE and dash_clock<=0:
		click_path.clear()
		dash_clock = 3
		invuln = 0.45
		ring(player.position,1.2,HEROES[hero].color)
		player.position += direction*3

func resume_game() -> void:
	if is_instance_valid(menu):
		menu.queue_free()
	paused = false
	playing = true
	update_view_ui()

func upgrade(choice: int) -> void:
	var travel := between_stages
	if choice == 0:
		damage_mult += 0.2
	elif choice == 1:
		armor_bonus += 40
		max_hp += 40
		hp = minf(hp+65,max_hp)
	else:
		hp = minf(hp+100,max_hp)
		q_clock = 0
		e_clock = 0
		w_clock = 0
	choosing = false
	update_view_ui()
	if is_instance_valid(menu):
		menu.queue_free()
	if travel:
		begin_stage(stage_index+1)

func clear_ending() -> void:
	if is_instance_valid(ending):
		ending.hide()
		ending.overlay.hide()
		ending.queue_free()
	ending = null
	if is_instance_valid(ui): ui.show()

func begin_ending() -> void:
	clear_ending()
	clear_battle()
	click_path.clear()
	if is_instance_valid(menu):
		menu.hide()
		menu.queue_free()
	ui.hide()
	player.position = Vector3(-2.2,0,0)
	player.rotation.y = -PI/3
	ending = VictoryArrival.new()
	world.add_child(ending)
	ending.setup(HEROES[hero].name)
	ending.completed.connect(complete_ending)
	camera.projection = Camera3D.PROJECTION_PERSPECTIVE
	camera.fov = 48
	camera.position = Vector3(0,4.5,-11)
	camera.look_at(Vector3(0,1.65,0))

func complete_ending() -> void:
	clear_ending()
	show_result(true)

func finish(won: bool) -> void:
	playing = false
	choosing = false
	paused = false
	campaign_won = won
	if won:
		begin_ending()
	else:
		show_result(false)

func show_result(won: bool) -> void:
	var col := panel("三关净化完成 · 远征胜利" if won else "英雄倒下 · 远征失败", "%s · 第 %d 关 %s · 击败 %d 个敌人 · 等级 %d · %02d:%02d" % [HEROES[hero].name,stage_index+1,Campaign.TITLES[stage_index],kills,level,int(elapsed)/60,int(elapsed)%60])
	button(col,"再次挑战",start_game.bind(hero))
	button(col,"更换英雄",show_menu)

func demo_segment(index: int) -> void:
	start_game(index)
	spawn_clock = 100
	for i in range(10):
		var e := spawn_enemy(2)
		var angle := i*TAU/10
		var radius := 3.2 if index==0 else 5.0
		e.node.position = Vector3(sin(angle)*radius,0,cos(angle)*radius)
		e.cooldown = 100
	announce(HEROES[index].name+" · 普通攻击","自动锁定 · 观察出手、弹道与命中反馈",HEROES[index].color)

func setup_ultimate_preview(index: int) -> void:
	start_game(index)
	spawn_clock = 100
	attack_clock = 100
	var positions: Array = []
	if index==0:
		positions = [Vector3(0,0,-3),Vector3(0.4,0,-8),Vector3(-0.4,0,-13),Vector3(0,0,-18),Vector3(4,0,-8)]
	elif index==1:
		for i in range(12): positions.append(Vector3(sin(i*TAU/12)*7,0,cos(i*TAU/12)*7))
	else:
		for i in range(4):
			for r in [5.4]: positions.append(Vector3(sin(i*PI/2)*r,0,-cos(i*PI/2)*r))
	for pos in positions:
		var e := spawn_enemy(2)
		e.node.position = pos
		e.cooldown = 100
	view_rig.set_mode(0,player.position,true)
	view_rig.zoom_value = 29
	if index==0:
		view_rig.set_mode(1,player.position,true)
		view_rig.zoom_value = 23
		view_rig.pitch = deg_to_rad(36)
		view_rig.yaw = -0.35
	view_rig.update(player.position,0,true)
	announce(HEROES[index].name+" · 第三技能","F 键 / 屏幕按钮 · 冷却 20 秒",HEROES[index].color)

func setup_camera_scene(index: int) -> void:
	start_game(0)
	spawn_clock = 100
	attack_clock = 100
	var positions := [Vector3(-3,0,-4),Vector3(-5,0,-7),Vector3(3,0,-5),Vector3(5,0,-8),Vector3(6,0,-7)]
	for i in range(5):
		var e := spawn_enemy(i)
		e.node.position = positions[i]
		e.cooldown = 100
	view_rig.set_mode(index,player.position,true)
	update_view_ui()

func _process(delta: float) -> void:
	if is_instance_valid(ending) and not auto_test:
		ending.advance(minf(delta,0.05))
		player.animate(minf(delta,0.05),false)
		if ending_preview:
			preview_frames += 1
			if preview_frames==10:
				get_viewport().get_texture().get_image().save_png("/workspace/brick-build/victory-arrival.png")
				get_tree().quit()
		return
	if enemy_preview>=0:
		preview_frames += 1
		if preview_frames==12:
			get_viewport().get_texture().get_image().save_png("/workspace/brick-build/enemies-%d.png" % enemy_preview)
			get_tree().quit()
		return
	if circle_preview>=0:
		preview_frames += 1
		if preview_frames==8:
			get_viewport().get_texture().get_image().save_png("/workspace/brick-build/circle-%d.png" % circle_preview)
			get_tree().quit()
		return
	delta = minf(delta,0.05)
	if ultimate_demo:
		var frame := ultimate_demo_tick%210
		if frame==0: setup_ultimate_preview(ultimate_demo_tick/210)
		if frame==30: skill(2)
		ultimate_demo_tick += 1
		if ultimate_demo_tick>=630:
			get_tree().quit()
			return
	if skill_preview>=0:
		preview_frames += 1
		if preview_frames==2: skill(2)
		if preview_frames==(13 if skill_preview!=2 else 25):
			get_viewport().get_texture().get_image().save_png("res://dist/ultimate-%d.png" % skill_preview)
			get_tree().quit()
			return
	if stage_demo:
		var frame := stage_demo_tick%210
		if frame==0:
			setup_stage_preview(stage_demo_tick/210)
		if frame==40:
			attack_clock = 0
		if frame==80:
			skill(0)
		if frame==135:
			skill(1)
		if frame>140:
			view_rig.orbit(Vector2(1.4,0))
		stage_demo_tick += 1
		if stage_demo_tick>=630:
			get_tree().quit()
			return
	if stage_preview>=0:
		preview_frames += 1
		if preview_frames==25:
			get_viewport().get_texture().get_image().save_png("res://dist/stage-%d.png" % stage_preview)
			get_tree().quit()
			return
	if camera_demo:
		var frame := camera_tick%180
		if frame==0:
			setup_camera_scene(camera_tick/180)
			announce(BattleCamera.NAMES[view_rig.mode],"同一战场 · 镜头旋转与角色朝向独立",Color("d6edff"))
		if frame==30:
			attack_clock = 0
		if frame==60:
			skill(0)
		if frame==110:
			skill(1)
		if frame>120:
			view_rig.orbit(Vector2(2,0))
		camera_tick += 1
		if camera_tick>=540:
			get_tree().quit()
			return
	if camera_preview>=0:
		preview_frames += 1
		if preview_frames==20:
			get_viewport().get_texture().get_image().save_png("res://dist/view-%d.png" % camera_preview)
			get_tree().quit()
			return
	if combat_demo:
		var local_frame := demo_tick%180
		if local_frame==0:
			demo_segment(demo_tick/180)
		if local_frame==45:
			skill(0)
		if local_frame==100:
			skill(1)
		demo_tick += 1
		if demo_tick>=540:
			get_tree().quit()
			return
	if combat_preview>=0:
		demo_tick += 1
		if demo_tick==12:
			get_viewport().get_texture().get_image().save_png("res://dist/combat-%d.png" % combat_preview)
			get_tree().quit()
			return
	for model in portrait_rigs:
		if is_instance_valid(model):
			model.animate(delta,model is ZombieVisual)
	if zombie_preview:
		preview_frames += 1
		if preview_frames==20:
			get_viewport().get_texture().get_image().save_png("res://dist/zombies-back.png" if "--zombie-back-preview" in OS.get_cmdline_user_args() else "res://dist/zombies.png")
			get_tree().quit()
			return
	if menu_preview:
		preview_frames += 1
		if preview_frames==20:
			get_viewport().get_texture().get_image().save_png("res://dist/heroes-back.png" if "--back-preview" in OS.get_cmdline_user_args() else "res://dist/heroes.png")
			get_tree().quit()
			return
	if preview:
		preview_frames += 1
		if preview_frames == 30:
			get_viewport().get_texture().get_image().save_png("/workspace/brick-outbreak/dist/gameplay.png")
			get_tree().quit()
			return
	if auto_test:
		run_smoke_test()
		return
	if not playing or choosing:
		return
	step(1.0/60.0 if combat_preview>=0 else delta)

func launch_enemy_projectile(e: Dictionary, form: String) -> void:
	var origin: Vector3 = e.node.mouth_position()
	var target := player.position+Vector3(0,1.0,0)
	var aim := (target-origin).normalized()
	var visual := EnemyProjectile.new()
	visual.build(form)
	world.add_child(visual)
	visual.position = origin
	if form!="catapult": visual.look_at(origin+aim)
	var shot := {"node":visual,"velocity":aim*6,"time":3.0,"damage":e.data.damage,"form":form}
	if form=="catapult":
		shot.origin = origin
		shot.target = player.position
		shot.age = 0.0
		shot.duration = clampf(origin.distance_to(target)/9.0,0.8,1.8)
		shot.marker = MeshInstance3D.new()
		var mesh := TorusMesh.new()
		mesh.inner_radius = 1.35
		mesh.outer_radius = 1.50
		mesh.rings = 24
		mesh.ring_segments = 6
		shot.marker.mesh = mesh
		shot.marker.material_override = HeroVisual.mat(Color("ff9567"),false,true)
		shot.marker.position = shot.target+Vector3(0,0.08,0)
		world.add_child(shot.marker)
	bullets.append(shot)
	fx.muzzle(origin,aim,Color("62df75") if form=="snake" else Color("ffc16b"))

func update_enemy_projectiles(delta: float) -> void:
	for b in bullets:
		b.time -= delta
		if b.get("form","")=="catapult":
			b.age += delta
			var t := clampf(b.age/b.duration,0,1)
			b.node.position = b.origin.lerp(b.target,t)+Vector3(0,sin(t*PI)*5.0,0)
			b.node.rotation.y += delta*2.5
			if t>=1:
				fx.impact(b.target,Color("c7aa79"),true)
				if player.position.distance_to(b.target)<=1.5: damage_player(b.damage)
				b.time = 0
		else:
			var before: Vector3 = b.node.position
			b.node.position += b.velocity*delta
			var closest := Geometry3D.get_closest_point_to_segment(player.position+Vector3(0,1,0),before,b.node.position)
			if closest.distance_to(player.position+Vector3(0,1,0))<0.7:
				damage_player(b.damage)
				b.time = 0
	for i in range(bullets.size()-1,-1,-1):
		if bullets[i].time<=0:
			bullets[i].node.queue_free()
			if bullets[i].has("marker"): bullets[i].marker.queue_free()
			bullets.remove_at(i)

func begin_enemy_charge(e: Dictionary) -> void:
	e.cooldown = 4.0
	e.charge_wait = 0.65
	e.charge_time = 0.85
	e.charge_dir = (player.position-e.node.position).normalized()
	e.charge_hit = false
	fx.wave(e.node.position,1.5,Color("ffba66"),0.65)
	fx.bolt(e.node.position+Vector3(0,0.1,0),e.node.position+e.charge_dir*9+Vector3(0,0.1,0),Color("ff8058"),0.65)

func update_enemy_charge(e: Dictionary, delta: float) -> bool:
	if e.get("charge_time",0.0)<=0: return false
	if e.charge_wait>0:
		e.charge_wait = maxf(0,e.charge_wait-delta)
		e.node.animate(delta,false,e.slow>0)
		return true
	var time := minf(delta,e.charge_time)
	e.charge_time -= time
	var before: Vector3 = e.node.position
	e.node.position += e.charge_dir*11.0*(0.5 if e.slow>0 else 1.0)*time
	e.node.position.x = clampf(e.node.position.x,-21,21)
	e.node.position.z = clampf(e.node.position.z,-21,21)
	e.node.rotation.y = atan2(-e.charge_dir.x,-e.charge_dir.z)
	e.node.attack()
	e.node.animate(time,true,e.slow>0)
	if not e.charge_hit and Geometry3D.get_closest_point_to_segment(player.position,before,e.node.position).distance_to(player.position)<1.2:
		e.charge_hit = true
		damage_player(e.data.damage)
	return true

func circle_blocks_movement() -> bool:
	return is_instance_valid(circle) and circle.landed and not circle_destroyed

func set_click_destination(point: Vector3) -> void:
	var blocked := circle_blocks_movement()
	var goal := ClickNavigation.destination(point,player.position,blocked)
	click_path = ClickNavigation.route(player.position,goal,blocked)
	if not click_path.is_empty():
		ring(goal,0.35,HEROES[hero].color)

func movement_input(axes: Vector2, delta: float) -> Vector3:
	if axes.length_squared()>0:
		click_path.clear()
		return view_rig.movement_axis(axes)
	if click_path.is_empty() or delta<=0: return Vector3.ZERO
	if circle_blocks_movement() and player.position.length()<2.65:
		player.position = player.position.normalized()*2.65 if player.position.length()>0.01 else Vector3.BACK*2.65
	# Replan if the previously airborne circle lands across the current route.
	if circle_blocks_movement() and not ClickNavigation.clear_segment(player.position,click_path[0]):
		var goal := ClickNavigation.destination(click_path.back(),player.position,true)
		click_path = ClickNavigation.route(player.position,goal,true)
		if click_path.is_empty(): return Vector3.ZERO
	while not click_path.is_empty() and player.position.distance_to(click_path[0])<=0.01:
		click_path.pop_front()
	if click_path.is_empty(): return Vector3.ZERO
	var offset := click_path[0]-player.position
	offset.y = 0
	# Clamp the last step to the target rather than overshooting and oscillating.
	return offset.normalized()*minf(1,offset.length()/(5.5*delta))

func step(delta: float) -> void:
	elapsed += delta
	attack_clock -= delta
	q_clock = maxf(0,q_clock-delta)
	e_clock = maxf(0,e_clock-delta)
	w_clock = maxf(0,w_clock-delta)
	invuln = maxf(0,invuln-delta)
	dash_clock = maxf(0,dash_clock-delta)
	buff = maxf(0,buff-delta)
	var axes := Vector2(float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT))-float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)),float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN))-float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)))
	var movement := movement_input(axes,delta)
	player.animate(delta,movement.length()>0)
	if movement.length()>0:
		direction = movement.normalized()
		player.position += movement*5.5*delta
		player.rotation.y = atan2(-direction.x,-direction.z)
	player.position.x = clampf(player.position.x,-21,21)
	player.position.z = clampf(player.position.z,-21,21)
	if is_instance_valid(circle) and circle.landed and not circle_destroyed and player.position.length()<2.65:
		player.position = player.position.normalized()*2.65 if player.position.length()>0.01 else Vector3(0,0,2.65)
	view_rig.update(player.position,delta)
	if is_instance_valid(circle) and not circle_destroyed:
		circle.animate(delta,stage_kills)
		circle.set_health(circle_target.hp,EnergyCircle.HEALTH[stage_index])
	update_campaign_spawns(delta)
	var nearest: Dictionary = {}
	var nearest_distance := 1000.0
	for e in enemies:
		if e.get("dead",false):
			continue
		var node: Node3D = e.node
		var data: Dictionary = e.data
		var offset: Vector3 = player.position-node.position
		var distance := offset.length()
		if distance<nearest_distance:
			nearest = e
			nearest_distance = distance
		e.flash = maxf(0,e.flash-delta)
		node.scale = Vector3.ONE*data.scale*(1.0+e.flash*0.5)
		node.set_overlay(white_flash if e.flash>0 else ice_overlay if e.slow>0 else null)
		e.cooldown -= delta
		e.slow = maxf(0,e.slow-delta)
		var ranged: bool = data.attack in ["arrow","snake","catapult"] or (data.attack=="hybrid" and distance>3.2*data.scale)
		var stop_distance := 8.0 if ranged else 1.0
		if update_enemy_charge(e,delta): continue
		node.animate(delta,distance>stop_distance,e.slow>0)
		if distance>stop_distance:
			node.position += offset.normalized()*data.speed*delta*(0.5 if e.slow>0 else 1.0)
			for other in enemies:
				if other == e or other.get("dead",false): continue
				var apart: Vector3 = node.position-other.node.position
				if apart.length()>0.01 and apart.length()<0.7:
					node.position += apart.normalized()*delta*1.5
		if offset.length()>0.01: node.rotation.y = atan2(-offset.x,-offset.z)
		if e.cooldown<=0:
			if data.attack=="charge" and distance<11 and distance>0.1:
				begin_enemy_charge(e)
			elif distance<(16.0 if data.attack=="catapult" else 12.0 if ranged else 1.5*data.scale):
				e.cooldown = 4.0 if data.attack=="catapult" else 2.5 if ranged else 1.5
				node.attack()
				if ranged:
					launch_enemy_projectile(e,"fireball" if data.attack=="hybrid" else data.attack)
				else:
					fx.slash(node.position,node.rotation.y,1.5*data.scale,Color("ffb86e"))
					damage_player(data.damage)
	if is_instance_valid(circle) and circle.landed and not circle_destroyed:
		var circle_distance := player.position.length()
		if circle_distance<nearest_distance:
			nearest = circle_target
			nearest_distance = circle_distance
	if not nearest.is_empty() and attack_clock<=0 and nearest_distance<(3.5 if hero==0 else 12.0):
		attack_clock = HEROES[hero].rate*(0.6 if buff>0 else 1.0)
		perform_attack(nearest)
	update_swings(delta)
	update_shots(delta)
	if not circle_destroyed: update_third_skills(delta)
	fx.update(delta)
	shake_strength = move_toward(shake_strength,0,delta*0.75)
	camera.position += Vector3(sin(elapsed*71),sin(elapsed*53),0)*shake_strength
	update_camera_occlusion()
	update_view_ui()
	banner_time = maxf(0,banner_time-delta)
	banner.modulate.a = minf(1,banner_time*3)
	banner_hint.modulate.a = banner.modulate.a
	update_enemy_projectiles(delta)
	for i in range(enemies.size()-1,-1,-1):
		if enemies[i].get("dead",false):
			enemies.remove_at(i)
	check_wave_clear()
	if xp >= level*8 and playing and not auto_test and not preview and combat_preview<0 and not combat_demo and not camera_demo and camera_preview<0 and not stage_demo and stage_preview<0 and not choosing and not ultimate_demo and skill_preview<0:
		xp -= level*8
		level += 1
		choosing = true
		var col := panel("升级 · 等级 %02d" % level,"选择一项强化。选择期间战斗暂停。")
		button(col,"锋利积木    /    伤害增加 20% 基础值",upgrade.bind(0))
		button(col,"坚固装甲    /    血量上限增加 40，恢复 65 血量",upgrade.bind(1))
		button(col,"重整旗鼓    /    恢复 100 血量，立即刷新技能",upgrade.bind(2))
	hp_bar.max_value = max_hp
	hp_bar.value = hp
	stage_hud.text = "%s · 第 %d / 3 关 · %s | 击败 %d / 10 · %s" % [Campaign.DIFFICULTIES[difficulty],stage_index+1,Campaign.TITLES[stage_index],mini(stage_kills,10),"击破中心法阵" if stage_kills>=10 else "法阵悬空"]
	hud.text = "%s    %d / %d 血量                 %02d:%02d    /    击败 %d    /    等级 %d" % [HEROES[hero].name,maxi(0,int(hp)),int(max_hp),int(elapsed)/60,int(elapsed)%60,kills,level]
	var names: Array = SKILL_NAMES[hero]
	for i in range(3):
		var cooldown := skill_cooldown(i)
		skill_buttons[i].text = ["Q · ","E · ","F · "][i]+names[i]+"\n"+("点击释放" if cooldown<=0 else "%.1f 秒" % cooldown)
		if hero==1 and i==1 and buff>0:
			skill_buttons[i].text = "E · 火力全开\n强化中 %.1f 秒" % buff
			skill_buttons[i].modulate = Color("ffd29a")
		elif hero==2 and i==2 and frost_age>=0:
			skill_buttons[i].text = "F · 四方霜降\n持续中 %.1f 秒" % (3.0-frost_age)
		else:
			skill_buttons[i].modulate = Color.WHITE
		skill_buttons[i].disabled = cooldown>0
	status.text = "Q %s  %s     E %s  %s     F %s  %s\n左键点地 / WASD 移动 · 空格闪避 · 击杀经验 %d / %d · 打破法阵使敌军消散后晋级" % [names[0],"就绪" if q_clock<=0 else "%.1fs" % q_clock,names[1],"就绪" if e_clock<=0 else "%.1fs" % e_clock,names[2],"就绪" if w_clock<=0 else "%.1fs" % w_clock,xp,level*8]

func check(condition: bool, description: String) -> void:
	if not condition:
		push_error("FAIL: "+description)
		get_tree().quit(1)
		assert(condition,description)
	print("PASS: "+description)

func camera_checks() -> void:
	start_game(0)
	view_rig.set_mode(0,player.position,true)
	check(camera.projection==Camera3D.PROJECTION_ORTHOGONAL,"top view uses an orthographic camera")
	view_rig.set_mode(1,player.position,true)
	var oblique_distance := camera.position.distance_to(player.position)
	check(camera.projection==Camera3D.PROJECTION_PERSPECTIVE,"oblique view uses perspective")
	view_rig.set_mode(2,player.position,true)
	check(camera.projection==Camera3D.PROJECTION_PERSPECTIVE and camera.position.distance_to(player.position)<oblique_distance,"third-person view is closer to the hero")
	view_rig.set_mode(0,player.position,true)
	for i in range(3):
		cycle_view()
	check(view_rig.mode==0,"view cycling wraps across three modes")
	var key := InputEventKey.new()
	key.pressed = true
	key.keycode = KEY_2
	_unhandled_key_input(key)
	key.keycode = KEY_3
	_unhandled_key_input(key)
	check(view_rig.mode==2,"number keys select battle views")
	key.keycode = KEY_V
	_unhandled_key_input(key)
	check(view_rig.mode==0,"V cycles the battle view")
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_RIGHT
	mouse.pressed = true
	_unhandled_input(mouse)
	var motion := InputEventMouseMotion.new()
	motion.relative = Vector2(80,-20)
	_input(motion)
	check(view_drag and absf(view_rig.yaw)>0.1,"right drag orbits the battle camera")
	mouse.pressed = false
	_input(mouse)
	check(not view_drag,"right release stops camera orbit")
	var zoom_before: float = view_rig.zoom_value
	mouse.button_index = MOUSE_BUTTON_WHEEL_UP
	mouse.pressed = true
	_unhandled_input(mouse)
	check(view_rig.zoom_value<zoom_before,"mouse wheel zooms the active view")
	var bounded := true
	for mode in range(3):
		view_rig.set_mode(mode,player.position,true)
		view_rig.zoom(1000)
		bounded = bounded and view_rig.zoom_value==BattleCamera.MAX_ZOOM[mode]
		view_rig.zoom(-1000)
		bounded = bounded and view_rig.zoom_value==BattleCamera.MIN_ZOOM[mode]
	check(bounded,"zoom stays within safe limits in every mode")
	view_rig.orbit(Vector2(100000,100000))
	var safe_pitch: bool = view_rig.pitch<=deg_to_rad(BattleCamera.MAX_PITCH[2])
	view_rig.orbit(Vector2(-100000,-100000))
	check(safe_pitch and view_rig.pitch>=deg_to_rad(BattleCamera.MIN_PITCH[2]) and absf(view_rig.yaw)<=PI,"camera pitch and yaw remain bounded")
	key.keycode = KEY_R
	_unhandled_key_input(key)
	check(view_rig.yaw==0 and view_rig.zoom_value==BattleCamera.DEFAULT_ZOOM[2],"R restores the active camera preset")
	view_rig.set_mode(1,player.position,true)
	view_rig.yaw = PI/2
	view_rig.update(player.position,0,true)
	var forward: Vector3 = view_rig.movement_axis(Vector2(0,-1))
	var right: Vector3 = view_rig.movement_axis(Vector2(1,0))
	check(forward.dot(Vector3.LEFT)>0.99 and right.dot(Vector3.FORWARD)>0.99,"WASD follows the displayed camera heading")
	check(is_equal_approx(view_rig.movement_axis(Vector2(1,-1)).length(),1),"diagonal camera-relative movement has no speed boost")
	start_game(1)
	view_rig.set_mode(2,player.position,true)
	var yaw_before: float = view_rig.yaw
	var eye_before := camera.position
	var target := spawn_enemy(0)
	target.node.position = Vector3(-5,0,-3)
	perform_attack(target)
	view_rig.update(player.position,0.1)
	check(view_rig.yaw==yaw_before and camera.position.distance_to(eye_before)<0.001 and absf(player.rotation.y)>0.1,"automatic attack facing cannot spin the camera")
	var blocker := spawn_enemy(0)
	blocker.node.position = Vector3(0.3,0,3)
	update_camera_occlusion()
	check(blocker.node.camera_occluded and blocker.node.meshes[0].material_override.albedo_color.a<0.4,"enemy between camera and hero becomes translucent")
	check(not target.node.camera_occluded and target.node.meshes[0].material_override.albedo_color.a==1,"occlusion fade leaves other horde instances opaque")
	hurt(blocker,1)
	check(blocker.node.meshes[0].material_overlay==null,"hit flash cannot make a faded blocker opaque")
	view_rig.set_mode(0,player.position,true)
	update_camera_occlusion()
	check(not blocker.node.camera_occluded and blocker.node.meshes[0].material_override==blocker.node.base_materials[0] and blocker.node.meshes[0].material_overlay==white_flash,"leaving occlusion restores original material and hit feedback")
	check(blocker.bar.material_override.billboard_mode==BaseMaterial3D.BILLBOARD_ENABLED,"enemy health bars face every battle camera")
	var safe_edges := true
	for pos in [Vector3(21,0,21),Vector3(-21,0,21),Vector3(21,0,-21),Vector3(-21,0,-21)]:
		view_rig.set_mode(2,pos,true)
		safe_edges = safe_edges and absf(camera.position.x)<=BattleCamera.ARENA_LIMIT+0.001 and absf(camera.position.z)<=BattleCamera.ARENA_LIMIT+0.001 and camera.position.y>3 and camera.position.distance_to(pos)>3
	check(safe_edges,"camera remains inside arena walls and lifts at map corners")
	view_rig.set_mode(0,player.position,true)
	eye_before = camera.position
	view_rig.set_mode(2,player.position)
	var initially_still: bool = camera.position==eye_before
	view_rig.update(player.position,0.016)
	check(initially_still and camera.position.distance_to(eye_before)>0 and camera.position.distance_to(eye_before)<10,"switching views transitions smoothly rather than teleporting")
	playing = false
	zoom_before = view_rig.zoom_value
	yaw_before = view_rig.yaw
	view_drag = true
	_input(motion)
	_unhandled_input(mouse)
	key.keycode = KEY_V
	_unhandled_key_input(key)
	check(not view_drag and view_rig.yaw==yaw_before and view_rig.zoom_value==zoom_before and view_rig.mode==2,"paused battles ignore camera controls")
	playing = true
	view_rig.yaw = 0.7
	start_game(0)
	check(view_rig.mode==2 and view_rig.yaw==0 and camera.position.distance_to(player.position)>3,"restart preserves view choice and recenters safely")
	view_button.pressed.emit()
	check(view_rig.mode==0 and view_button.text.contains(BattleCamera.NAMES[0]) and view_button.visible,"on-screen view button switches mode and updates its label")

func campaign_visual_checks() -> void:
	for stage in range(3):
		start_game(0)
		begin_stage(stage)
		var budget := true
		for kind in range(6):
			var e := spawn_enemy(kind)
			var model: Node3D = e.node
			check(model.stage==stage and model.identity==kind and (model.snake_segments.size()==12 if stage==0 and kind==3 else model.details>40),"stage %d enemy %d uses its themed articulated model" % [stage,kind])
			budget = budget and model.meshes.size()<=48 and model.meshes.size()<model.details
			model.phase = 0
			model.animate(0,false)
			var before: float = model.leg_l.rotation.x
			model.animate(0.1,true)
			var walked: bool = absf(model.leg_l.rotation.x-before)>0.01
			model.attack()
			model.animate(0.12,true)
			check(walked and model.jaw.rotation.x>0.4,"stage %d enemy %d has moving legs and an attack action" % [stage,kind])
			var restored := true
			for overlay in [white_flash,ice_overlay,null]:
				model.set_overlay(overlay)
				for part in model.meshes:
					restored = restored and part.material_overlay==overlay
			check(restored,"stage %d enemy %d retains hit and frost feedback" % [stage,kind])
			check(e.bar.global_position.y>model.head.global_position.y+0.1,"stage %d enemy %d health bar clears its head" % [stage,kind])
			model.set_overlay(white_flash)
			model.set_camera_occluded(true)
			var faded: bool = model.meshes[0].material_override.albedo_color.a<0.4 and model.meshes[0].material_overlay==null
			model.set_camera_occluded(false)
			check(faded and model.meshes[0].material_override==model.base_materials[0] and model.meshes[0].material_overlay==white_flash,"stage %d enemy %d fades and restores its own materials" % [stage,kind])
			model.set_overlay(null)
			var copy := CampaignEnemy.new()
			copy.build_for_stage(stage,kind,model.variant)
			check(copy.meshes[0].mesh==model.meshes[0].mesh,"stage %d enemy %d shares baked geometry within its type" % [stage,kind])
			copy.free()
			if stage==0:
				check((model.snake_segments.size()==12 if kind==3 else model.rear_legs.size()==2) and model.tail!=null and model.arm_l==null,"infected animal %d has a species-specific skeleton without human arms" % kind)
		check(budget,"stage %d enemy render mesh count stays bounded" % stage)
		var model: Node3D = enemies[0].node
		var before_phase: float = model.phase
		model.animate(0.1,true,true)
		check(is_equal_approx(model.phase-before_phase,0.29 if stage==0 else 0.21),"stage %d frost halves animation speed" % stage)
		clear_battle()
		spawn_clock = 100
		attack_clock = 100
		invuln = 0
		var ranged := spawn_enemy(3)
		ranged.node.position = Vector3(0,0,-6)
		ranged.cooldown = 0
		step(0.01)
		check(bullets.size()==1 and bullets[0].node.position.distance_to(ranged.node.mouth_position())<0.1,"stage %d ranged attack launches from its actual model" % stage)
		for i in range(30): step(0.05)
		check(is_equal_approx(hp,max_hp-ranged.data.damage) and bullets.is_empty(),"stage %d projectile reaches and damages the player once" % stage)
		gallery_stage = stage
		show_zombie_gallery()
		var correct: bool = portrait_rigs.size()==6
		for i in range(portrait_rigs.size()):
			correct = correct and portrait_rigs[i] is CampaignEnemy and portrait_rigs[i].stage==stage and portrait_rigs[i].identity==i
		check(correct,"stage %d bestiary uses all six actual battle models" % stage)
		var portrait: Node3D = portrait_rigs[0]
		var yaw := portrait.rotation.y
		var motion := InputEventMouseMotion.new()
		motion.button_mask = MOUSE_BUTTON_MASK_LEFT
		motion.relative = Vector2(40,0)
		portrait.get_parent().get_parent().gui_input.emit(motion)
		check(portrait.rotation.y>yaw+0.5,"stage %d bestiary supports model rotation" % stage)
	check(stage_scenes[0].name=="Savanna" and stage_scenes[1].name=="PyramidNecropolis" and stage_scenes[2].name=="GreatWallFortress","campaign builds three distinct environment roots")
	var wolf := CampaignEnemy.new()
	var mummy := CampaignEnemy.new()
	var clay := CampaignEnemy.new()
	wolf.build_for_stage(0,0)
	mummy.build_for_stage(1,0)
	clay.build_for_stage(2,0)
	check(wolf.meshes[0].mesh!=mummy.meshes[0].mesh and mummy.meshes[0].mesh!=clay.meshes[0].mesh,"shared mesh cache cannot mix different campaign themes")
	wolf.free()
	mummy.free()
	clay.free()

func campaign_flow_checks() -> void:
	start_game(1)
	for stage in range(3):
		check(stage_index==stage and playing and not choosing,"circle campaign stage %d starts in order" % stage)
		check(circle.tint==EnergyCircle.COLORS[stage] and circle_target.hp==EnergyCircle.HEALTH[stage],"stage %d circle color and health" % stage)
		check(circle.parts>100 and circle.position.y>4 and not circle.landed,"brick platform, crown, sockets and energy ornaments float initially")
		hurt(circle_target,10000,true,false,true)
		check(circle_target.hp==EnergyCircle.HEALTH[stage],"airborne circle is invulnerable")
		for i in range(10):
			spawn_clock = 0
			update_campaign_spawns(0.01)
			var e: Dictionary = enemies.back()
			check(Vector2(e.node.position.x,e.node.position.z).length()<3,"enemy emerges from center circle")
			hurt(e,e.hp+1)
			enemies.erase(e)
			circle.animate(0.01,stage_kills)
			if i==8: check(not circle.landing,"nine defeats leave circle airborne")
		check(circle.landing and not circle.landed,"tenth defeat initiates animated descent")
		var height: float = circle.position.y
		auto_test = false
		playing = false
		_process(0.05)
		playing = true
		auto_test = true
		check(circle.position.y==height,"pause freezes circle descent")
		circle.animate(3,stage_kills)
		check(circle.landed and circle.position==Vector3.ZERO,"circle lands at exact map center")
		check_wave_clear()
		check(not stage_cleared and playing,"ten kills and no enemies cannot finish an intact circle")
		for i in range(15):
			spawn_clock = 0
			update_campaign_spawns(1)
		check(enemies.size()==12,"continuous spawning obeys twelve-enemy live cap")
		var old_count := stage_spawned
		var dead: Dictionary = enemies.pop_back()
		hurt(dead,dead.hp+1)
		spawn_clock = 0
		update_campaign_spawns(1)
		check(stage_spawned==old_count+1 and enemies.size()==12,"circle replenishes enemies after a defeat")
		for i in range(40):
			for enemy in enemies: hurt(enemy,enemy.hp+1)
			enemies.clear()
			spawn_clock = 0
			update_campaign_spawns(1)
		check(stage_spawned>Campaign.total(stage) and not circle_destroyed and not stage_cleared,"intact circle spawns beyond the old finite quota")
		var health_before: float = circle_target.hp
		hurt(circle_target,100)
		check(circle_target.hp==health_before-100,"basic attacks deal full circle damage")
		hurt(circle_target,100,true,false,true)
		check(circle_target.hp==health_before-150,"skills deal exactly half circle damage")
		check(circle.health.text.contains(str(int(circle_target.hp))) and is_equal_approx(circle.bar.scale.x,circle_target.hp/EnergyCircle.HEALTH[stage]),"circle label and health bar update immediately")
		# Actual Q range and damage path.
		player.position = Vector3(0,0,2)
		q_clock = 0
		health_before = circle_target.hp
		skill(0)
		check(is_equal_approx(circle_target.hp,health_before-HEROES[hero].q_damage*damage_mult*0.5),"Q applies reduced circle damage")
		# The ranger meteor must land before dealing half of its upgraded damage.
		w_clock = 0
		health_before = circle_target.hp
		skill(2)
		update_third_skills(0.64)
		check(circle_target.hp==health_before,"meteor cannot damage circle before landing")
		update_third_skills(0.02)
		check(is_equal_approx(circle_target.hp,health_before-90*damage_mult),"meteor deals half damage on impact")
		hurt(circle_target,10000)
		check(circle_destroyed and circle_target.dead and circle_target.hp==0,"circle destruction clamps health and disables attacks")
		check(enemies.all(func(e): return e.get("dead",false) and not e.node.visible),"circle destruction makes all surviving enemies disappear")
		old_count = stage_spawned
		update_campaign_spawns(10)
		check(stage_spawned==old_count,"destroyed circle stops spawning immediately")
		check_wave_clear()
		check(stage_cleared and enemies.is_empty() and shots.is_empty() and bullets.is_empty(),"circle completion cleans all battle objects")
		if stage<2:
			check(between_stages and choosing,"destroyed circle opens intermission")
			var old_damage := damage_mult
			level = 3
			xp = 3
			upgrade(0)
			check(level==3 and xp==3 and damage_mult>old_damage and hp==max_hp,"transition retains upgrades and fully heals")
			check(not circle_destroyed and stage_kills==0 and not circle.landed,"next stage creates a fresh airborne circle")
	check(campaign_won and not playing and stage_index==2,"destroying third circle wins campaign")
	start_game(0)
	check(stage_index==0 and circle_target.hp==1000 and stage_kills==0,"restart restores green circle and objective")
	circle.animate(3,10)
	player.position = Vector3(0,0,2)
	player.rotation.y = 0
	var before: float = circle_target.hp
	cast_third_skill()
	check(circle_target.hp==before-500,"dragon execution deals half max circle health instead of instant destruction")
	start_game(2)
	circle.animate(3,10)
	player.position = Vector3(0,0,2)
	player.rotation.y = 0
	cast_third_skill()
	for i in range(65): update_third_skills(0.05)
	check(is_equal_approx(circle_target.hp,900),"twelve frost pulses total one hundred circle damage")
	for index in range(3):
		start_game(index)
		circle.animate(3,10)
		player.position = Vector3(0,0,3)
		var original: float = circle_target.hp
		perform_attack(circle_target)
		if index==0:
			update_swings(0.09)
			check(circle_target.hp==original,"melee circle damage waits for blade impact")
			update_swings(0.02)
		else:
			check(circle_target.hp==original,"ranged circle damage waits for projectile impact")
			update_shots(1)
		check(circle_target.hp==original-HEROES[index].damage,"hero %d basic attack hits circle at full damage" % index)
		original = circle_target.hp
		player.position = Vector3(0,0,20)
		area_damage(6,100)
		check(circle_target.hp==original,"out-of-range area damage cannot hit circle")
		if index!=1:
			player.position = Vector3(0,0,7) if index==0 else Vector3(0,0,3)
			direction = Vector3.FORWARD
			skill(1)
			check(circle_target.hp==original-60,"hero %d E deals half circle damage" % index)
	playing = false

func combat_checks() -> void:
	start_game(0)
	attack_clock = 100
	spawn_clock = 100
	var melee_target := spawn_enemy(2)
	melee_target.node.position = Vector3(2,0,0)
	melee_target.cooldown = 100
	perform_attack(melee_target)
	check(melee_target.hp==240 and swings.size()==1,"melee begins with a visible windup")
	step(0.05)
	check(melee_target.hp==240,"melee windup does not deal premature damage")
	step(0.08)
	check(melee_target.hp==210 and swings.is_empty(),"melee damage settles once at the slash")
	for index in [1,2]:
		start_game(index)
		spawn_clock = 100
		attack_clock = 100
		var target := spawn_enemy(2)
		target.node.position = Vector3(0,0,-7)
		target.cooldown = 100
		perform_attack(target)
		check(shots.size()==1 and target.hp==240,"hero %d projectile leaves weapon before damage" % index)
		var shot: Dictionary = shots[0]
		var start: Vector3 = shot.visual.start
		check(start.distance_to(player.emission_point())<0.01 and start.y>0.5,"hero %d projectile begins at held weapon" % index)
		step(shot.duration*0.4)
		check(target.hp==240 and shots.size()==1,"hero %d no premature projectile damage" % index)
		step(shot.duration*0.7)
		check(target.hp==240-HEROES[index].damage and shots.is_empty(),"hero %d damage settles once on arrival" % index)
		var numbers := 0
		for e in fx.active:
			if e.mode=="number" and e.node.text==str(int(HEROES[index].damage)):
				numbers += 1
		check(numbers==1,"hero %d damage popup matches actual hit" % index)
		if index==2:
			check(target.slow>0,"ice projectile applies slow on impact")
	start_game(1)
	var target := spawn_enemy(2)
	target.node.position = Vector3(0,0,-6)
	perform_attack(target)
	hurt(target,1000)
	update_shots(1)
	check(kills==1 and shots.is_empty(),"in-flight bolt cannot reward a dead target twice")
	start_game(0)
	spawn_clock = 100
	attack_clock = 100
	target = spawn_enemy(2)
	target.node.position = Vector3(2,0,0)
	target.cooldown = 100
	hurt(target,10)
	check(target.node.meshes[0].material_overlay==white_flash,"actual hit visibly flashes enemy")
	step(0.2)
	check(target.node.meshes[0].material_overlay==null,"hit flash restores original material")
	for index in range(3):
		start_game(index)
		var count: int = fx.created
		skill(0)
		check(fx.created>count and banner.text.begins_with("Q"),"hero %d Q has visible FX and skill title" % index)
		count = fx.created
		skill(0)
		check(fx.created==count,"hero %d cooldown cannot duplicate attack FX" % index)
		skill(1)
		check(fx.created>count and banner.text.begins_with("E"),"hero %d E has visible FX and skill title" % index)
	start_game(1)
	target = spawn_enemy(2)
	target.node.position = Vector3(0,0,-5)
	perform_attack(target)
	var age: float = fx.active[0].age
	var travel: float = shots[0].elapsed
	playing = false
	auto_test = false
	_process(0.2)
	auto_test = true
	check(fx.active[0].age==age and shots[0].elapsed==travel,"pause freezes effects and projectile flight")
	start_game(0)
	check(fx.active.is_empty() and shots.is_empty(),"restart removes old projectiles and effects")
	for i in range(260):
		fx.wave(Vector3.ZERO,1,Color.WHITE,0.1)
	check(fx.active.size()<=CombatFX.LIMIT,"effect population remains bounded")
	fx.update(1)
	check(fx.active.is_empty(),"expired FX are released")

func balance_checks() -> void:
	for stage in range(3):
		for kind in range(6):
			var base: Dictionary = ENEMIES[kind].duplicate()
			var normal := Campaign.stats(stage,kind,base,1)
			var easy := Campaign.stats(stage,kind,base,0)
			var hard := Campaign.stats(stage,kind,base,2)
			var rate: float = [1.10,1.15,1.20][stage]
			check(is_equal_approx(easy.hp,normal.hp*0.8) and is_equal_approx(easy.speed,normal.speed*0.8) and is_equal_approx(easy.damage,normal.damage*0.8),"easy stage %d enemy %d reduces all three stats by 20 percent" % [stage,kind])
			check(is_equal_approx(hard.hp,normal.hp*rate) and is_equal_approx(hard.speed,normal.speed*rate) and is_equal_approx(hard.damage,normal.damage*(1.0 if stage==0 else rate)),"hard stage %d enemy %d applies the specified stage multiplier" % [stage,kind])
			check(base==ENEMIES[kind] and Campaign.stats(stage,kind,base,1)==normal,"difficulty calculations cannot mutate normal-mode base stats")
	for setting in range(3):
		difficulty = setting
		start_game(0)
		begin_stage(2)
		var target := spawn_enemy(2)
		var expected := Campaign.stats(2,2,ENEMIES[2],setting)
		check(target.hp==expected.hp and target.data.speed==expected.speed and target.data.damage==expected.damage,"difficulty %d is used by real spawned enemies" % setting)
		show_menu()
		check(difficulty_picker.item_count==3 and difficulty_picker.selected==setting,"difficulty %d remains selected after returning to hero selection" % setting)
	for setting in range(3):
		for stage in range(3):
			difficulty = setting
			start_game(0)
			begin_stage(stage)
			spawn_clock = 100
			attack_clock = 100
			var e := spawn_enemy(0)
			e.node.position = Vector3(0,0,-5)
			e.cooldown = 100
			step(0.1)
			check(is_equal_approx(e.node.position.z,-5+e.data.speed*0.1),"difficulty %d stage %d changes actual enemy movement" % [setting,stage])
			e.node.position = Vector3(1.2,0,0)
			e.cooldown = 0
			invuln = 0
			var previous := hp
			step(0.01)
			check(is_equal_approx(hp,previous-e.data.damage),"difficulty %d stage %d changes actual enemy attack damage" % [setting,stage])
	show_menu()
	difficulty_picker.select(0)
	difficulty_picker.item_selected.emit(0)
	start_game(1)
	check(difficulty==0 and is_equal_approx(spawn_enemy(4).hp,Campaign.BOSS_HP[0]*0.8),"difficulty selector controls the next run including bosses")
	difficulty = 1
	for index in range(3):
		start_game(index)
		for stage in range(3):
			begin_stage(stage)
			check(hp==HEROES[index].stage_hp[stage] and max_hp==hp,"hero %d uses the requested stage %d base health" % [index,stage])
		start_game(index)
		upgrade(1)
		for stage in range(3):
			begin_stage(stage)
			check(armor_bonus==40 and max_hp==HEROES[index].stage_hp[stage]+40 and hp==max_hp,"hero %d stage %d adds retained armour to stage base health" % [index,stage])
	start_game(0)

func third_skill_checks() -> void:
	difficulty = 1
	for index in range(3):
		start_game(index)
		var inside := spawn_enemy(2)
		var outside := spawn_enemy(2)
		inside.node.position = Vector3(HEROES[index].q_radius,0,0)
		outside.node.position = Vector3(HEROES[index].q_radius+0.1,0,0)
		skill(0)
		check(is_equal_approx(inside.hp,240.0-HEROES[index].q_damage) and outside.hp==240,"hero %d Q uses its requested radius and base damage" % index)
		check(q_clock==HEROES[index].q,"hero %d Q retains the requested cooldown" % index)
	start_game(1)
	skill(1)
	check(buff==8 and e_clock==16,"ranger firepower buff lasts eight seconds with sixteen-second cooldown")
	spawn_clock = 100
	attack_clock = 0
	var ranged := spawn_enemy(2)
	ranged.node.position = Vector3(0,0,-7)
	ranged.cooldown = 100
	step(0.01)
	check(is_equal_approx(attack_clock,HEROES[1].rate*0.6),"ranger buff reduces the real automatic attack interval by forty percent")
	clear_battle()
	spawn_clock = 100
	for i in range(160): step(0.05)
	check(buff==0,"ranger buff expires after eight seconds of active battle")
	start_game(2)
	var near := spawn_enemy(2)
	var far := spawn_enemy(2)
	near.node.position = Vector3(9.9,0,0)
	far.node.position = Vector3(10.1,0,0)
	skill(1)
	check(near.hp==120 and near.slow==3 and far.hp==240,"oracle E reaches radius ten and preserves damage and slow")
	start_game(0)
	var line := spawn_enemy(2)
	var boss := spawn_enemy(4)
	var beside := spawn_enemy(2)
	var behind := spawn_enemy(2)
	line.node.position = Vector3(1.4,0,-5)
	boss.node.position = Vector3(0,0,-18)
	beside.node.position = Vector3(1.8,0,-5)
	behind.node.position = Vector3(0,0,3)
	skill(2)
	check(line.get("dead",false) and boss.get("dead",false) and beside.hp==240 and behind.hp==240,"dragon cut instantly clears the forward lane including a boss, leaving side and rear enemies")
	var dragon := false
	for effect in fx.active: dragon = dragon or effect.mode=="dragon"
	check(dragon and player.cast_variant==2 and player.skill_time>0,"dragon cut combines dragon-shaped energy and the dedicated overhead slash")
	check(w_clock==20 and playing and not campaign_won,"third skill cooldown is twenty seconds and dragon kills cannot bypass stage clearance")
	var old_kills := kills
	skill(2)
	check(kills==old_kills and w_clock==20,"third skill cannot bypass its cooldown or reward dead enemies twice")
	start_game(1)
	near = spawn_enemy(2)
	far = spawn_enemy(2)
	near.node.position = Vector3(-9.8,0,0)
	far.node.position = Vector3(10.1,0,0)
	skill(2)
	var meteors := 0
	for effect in fx.active:
		if effect.mode=="meteor": meteors += 1
	check(meteors==13 and near.hp==240 and ultimate_jobs.size()==1,"meteor skill visibly falls before applying damage")
	update_third_skills(0.30)
	check(near.hp==240,"meteor damage waits for landing")
	player.position = Vector3(15,0,0)
	update_third_skills(0.36)
	check(near.hp==60 and far.hp==240 and ultimate_jobs.is_empty(),"meteor landing deals 180 once in radius ten at the marked cast location")
	start_game(2)
	var targets: Array = []
	for pos in [Vector3(0,0,-5),Vector3(5,0,0),Vector3(0,0,5),Vector3(-5,0,0),Vector3.ZERO,Vector3(4,0,4),Vector3(0,0,-6.1)]:
		var e := spawn_enemy(2)
		e.node.position = pos
		targets.append(e)
	skill(2)
	check(targets[0].hp==240 and frost_pulses==1,"four-direction frost starts with visible projectiles before impact")
	for i in range(65):
		update_third_skills(0.05)
		fx.update(0.05)
	var correct := true
	for i in range(5): correct = correct and is_equal_approx(targets[i].hp,40)
	check(correct,"four-direction frost deals 200 total per covered target without quadrupling centre damage")
	check(targets[5].hp==240 and targets[6].hp==240,"frost arrows respect four narrow lanes and radius six")
	check(frost_pulses==12 and frost_age<0 and ultimate_jobs.is_empty(),"frost barrage ends after three seconds and twelve pulses")
	start_game(2)
	skill(2)
	var old_age := frost_age
	var old_delay: float = ultimate_jobs[0].delay
	var old_w := w_clock
	playing = false
	auto_test = false
	_process(0.5)
	auto_test = true
	check(frost_age==old_age and ultimate_jobs[0].delay==old_delay and w_clock==old_w,"pause freezes channel time, pending impacts and third-skill cooldown")
	playing = true
	choosing = true
	auto_test = false
	_process(0.5)
	auto_test = true
	check(frost_age==old_age and ultimate_jobs[0].delay==old_delay and w_clock==old_w,"upgrade selection also freezes sustained third skills")
	choosing = false
	begin_stage(1)
	check(w_clock==0 and frost_age<0 and ultimate_jobs.is_empty() and fx.active.is_empty(),"new stage refreshes the third skill and clears old channels, falling fireballs and impacts")
	start_game(1)
	var key := InputEventKey.new()
	key.pressed = true
	key.keycode = KEY_W
	_unhandled_key_input(key)
	check(w_clock==0,"W remains movement and cannot accidentally fire the third skill")
	key.keycode = KEY_F
	_unhandled_key_input(key)
	check(w_clock==20 and ultimate_jobs.size()==1,"F keyboard input triggers the third skill")
	start_game(1)
	skill_buttons[2].pressed.emit()
	check(w_clock==20 and ultimate_jobs.size()==1,"third on-screen skill button triggers the actual skill")
	q_clock = 3
	e_clock = 3
	upgrade(2)
	check(q_clock==0 and e_clock==0 and w_clock==0,"skill-refresh upgrade also refreshes the third slot")
	start_game(0)
	spawn_clock = 100
	attack_clock = 100
	skill(2)
	for i in range(399): step(0.05)
	check(w_clock>0 and w_clock<0.06,"third skill remains unavailable before twenty active seconds")
	step(0.06)
	check(w_clock==0 and not skill_buttons[2].disabled,"third skill becomes ready after twenty active seconds")
	for index in [1,2]:
		start_game(index)
		damage_mult = 1.2
		var target := spawn_enemy(2)
		target.node.position = Vector3(0,0,-5)
		skill(2)
		for i in range(65): update_third_skills(0.05)
		check(target.get("dead",false) if index==2 else is_equal_approx(target.hp,24),"hero %d third skill receives retained damage upgrades" % index)
	start_game(2)
	skill(2)
	start_game(0)
	check(w_clock==0 and ultimate_jobs.is_empty() and frost_age<0 and armor_bonus==0,"restart resets third skills, channels and additional armour")

func enemy_attack_checks() -> void:
	for stage in range(3):
		start_game(0)
		begin_stage(stage)
		spawn_clock = 100
		attack_clock = 100
		check(Campaign.ENEMY_NAMES[stage].size()==6,"stage %d has six enemies in roster" % stage)
		var roster: Array = []
		for wave in Campaign.WAVES[stage]:
			for kind in wave:
				if kind not in roster: roster.append(kind)
		check(roster.size()==6,"stage %d spawn patterns include every enemy" % stage)
		for kind in [2,3,4] if stage<2 else [3]:
			var enemy := spawn_enemy(kind)
			enemy.node.position = Vector3(0,0,-8)
			var form: String = "fireball" if kind==4 else enemy.data.attack
			launch_enemy_projectile(enemy,form)
			var shot: Dictionary = bullets.back()
			var velocity: Vector3 = shot.velocity
			var before: Vector3 = shot.node.position
			player.position = Vector3(10,0,0)
			update_enemy_projectiles(0.1)
			check(shot.node.form==form and shot.velocity==velocity and shot.node.position.is_equal_approx(before+velocity*0.1),"stage %d %s projectile keeps its launch direction after hero moves" % [stage,form])
			clear_battle()
			player.position = Vector3.ZERO
		if stage<2:
			var boss := spawn_enemy(4)
			boss.node.position = Vector3(0,0,-8)
			boss.cooldown = 0
			step(0.01)
			check(bullets.size()==1 and bullets[0].form=="fireball","stage %d boss uses ranged fireballs" % stage)
			clear_battle()
			boss = spawn_enemy(4)
			boss.node.position = Vector3(0,0,-1)
			boss.cooldown = 0
			invuln = 0
			var previous := hp
			step(0.01)
			check(hp==previous-boss.data.damage and bullets.is_empty(),"stage %d boss switches to close claw attack" % stage)
			clear_battle()
			var charger := spawn_enemy(5)
			charger.node.position = Vector3(0,0,-7)
			begin_enemy_charge(charger)
			var heading: Vector3 = charger.charge_dir
			var start: Vector3 = charger.node.position
			update_enemy_charge(charger,0.3)
			check(charger.node.position==start,"stage %d charge has a stationary warning phase" % stage)
			player.position = Vector3(6,0,0)
			update_enemy_charge(charger,0.4)
			previous = hp
			update_enemy_charge(charger,1)
			check(charger.charge_dir==heading and hp==previous and charger.node.position.z>start.z,"stage %d charge is directional and can be dodged" % stage)
			player.position = Vector3.ZERO
			charger.node.position = Vector3(0,0,-4)
			begin_enemy_charge(charger)
			update_enemy_charge(charger,0.7)
			invuln = 0
			previous = hp
			update_enemy_charge(charger,0.5)
			check(hp==previous-charger.data.damage and charger.charge_hit,"stage %d charge sweeps through and damages hero once" % stage)
			clear_battle()
		else:
			var siege := spawn_enemy(5)
			check(siege.node.wheels.size()==4 and is_instance_valid(siege.node.launch_arm),"terracotta catapult has four wheels and animated throwing arm")
			siege.node.position = Vector3(0,0,-10)
			launch_enemy_projectile(siege,"catapult")
			var shot: Dictionary = bullets.back()
			check(shot.target==Vector3.ZERO and shot.node.get_child_count()>=12 and is_instance_valid(shot.marker),"hamburger-shaped stone snapshots hero location and marks impact zone")
			player.position = Vector3(5,0,0)
			var previous := hp
			update_enemy_projectiles(0.4)
			check(shot.target==Vector3.ZERO and shot.node.position.y>shot.origin.lerp(shot.target,shot.age/shot.duration).y,"catapult follows a fixed parabolic arc")
			update_enemy_projectiles(2)
			check(hp==previous and bullets.is_empty(),"hero can leave the marked stone impact zone to avoid damage")
			player.position = Vector3.ZERO
			launch_enemy_projectile(siege,"catapult")
			invuln = 0
			update_enemy_projectiles(2)
			check(hp==previous-siege.data.damage and bullets.is_empty(),"stone deals damage once at its original landing zone")
			launch_enemy_projectile(siege,"catapult")
			shot = bullets.back()
			playing = false
			auto_test = false
			_process(0.1)
			auto_test = true
			check(shot.age==0,"pause freezes catapult flight")
			var marker: Node = shot.marker
			clear_battle()
			check(marker.is_queued_for_deletion() and bullets.is_empty(),"battle cleanup removes catapult projectile and landing marker")
	playing = false

func click_movement_checks() -> void:
	start_game(0)
	clear_battle()
	spawn_clock = 100
	attack_clock = 100
	for mode in range(3):
		player.position = Vector3.ZERO
		view_rig.set_mode(mode,player.position,true)
		var goal := Vector3(2,0,-3)
		var click := InputEventMouseButton.new()
		click.button_index = MOUSE_BUTTON_LEFT
		click.pressed = true
		click.position = camera.unproject_position(goal)
		_unhandled_input(click)
		check(not click_path.is_empty() and click_path.back().distance_to(goal)<0.001,"view %d left click projects onto the ground correctly" % mode)
		var before := player.position
		step(0.05)
		check(is_equal_approx(player.position.distance_to(before),0.275),"view %d click movement uses normal hero speed" % mode)
		for i in range(30): step(0.05)
		check(player.position.distance_to(goal)<0.001 and click_path.is_empty(),"view %d hero arrives and stops without overshooting" % mode)
	set_click_destination(Vector3(5,0,5))
	var axis := movement_input(Vector2(1,1),0.1)
	check(click_path.is_empty() and is_equal_approx(axis.length(),1),"keyboard movement cancels click target and keeps diagonal speed normalized")
	set_click_destination(Vector3(100,20,-100))
	check(click_path.back()==Vector3(21,0,-21),"off-arena click targets are clamped to playable ground")
	set_click_destination(Vector3(1,0,1))
	set_click_destination(Vector3(-4,0,4))
	check(click_path.back()==Vector3(-4,0,4),"a second click replaces the previous destination")
	var key := InputEventKey.new()
	key.keycode = KEY_W
	key.pressed = true
	_unhandled_key_input(key)
	check(click_path.is_empty(),"W key event cancels a click route immediately")
	set_click_destination(Vector3(6,0,0))
	var position_before := player.position
	playing = false
	auto_test = false
	_process(0.1)
	auto_test = true
	check(player.position==position_before and not click_path.is_empty(),"pause freezes click movement and preserves its destination")
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	click.pressed = true
	click.position = Vector2(100,100)
	var previous_goal: Vector3 = click_path.back()
	_unhandled_input(click)
	check(click_path.back()==previous_goal,"paused game ignores new movement clicks")
	playing = true
	choosing = true
	_unhandled_input(click)
	check(click_path.back()==previous_goal,"upgrade selection ignores ground clicks")
	choosing = false
	start_game(0)
	check(click_path.is_empty(),"restart clears click movement")
	spawn_clock = 100
	attack_clock = 100
	circle.animate(3,10)
	player.position = Vector3(0,0,6)
	set_click_destination(Vector3.ZERO)
	check(click_path.back().is_equal_approx(Vector3(0,0,2.8)),"clicking landed circle chooses a reachable position beside it")
	set_click_destination(Vector3(0,0,-6))
	check(click_path.size()>1,"opposite-side click creates a route around the landed circle")
	var safe := true
	for i in range(130):
		step(0.05)
		safe = safe and player.position.length()>=2.649
	check(safe and player.position.distance_to(Vector3(0,0,-6))<0.01 and click_path.is_empty(),"hero walks around the circle and reaches the opposite destination")
	start_game(0)
	spawn_clock = 100
	attack_clock = 100
	player.position = Vector3(0,0,6)
	set_click_destination(Vector3(0,0,-6))
	circle.animate(3,10)
	for i in range(130): step(0.05)
	check(player.position.distance_to(Vector3(0,0,-6))<0.01,"route replans when an airborne circle lands in its path")
	set_click_destination(Vector3(5,0,0))
	begin_stage(1)
	check(click_path.is_empty(),"stage transitions clear old movement targets")
	set_click_destination(Vector3(5,0,0))
	show_menu()
	check(click_path.is_empty(),"returning to hero selection clears movement targets")

func ending_checks() -> void:
	start_game(0)
	finish(false)
	check(not is_instance_valid(ending) and not campaign_won,"defeat never triggers recruitment scene")
	start_game(0)
	circle.animate(3,10)
	hurt(circle_target,10000)
	check_wave_clear()
	check(not is_instance_valid(ending) and between_stages,"first-stage victory keeps intermission without final recruitment")
	for index in range(3):
		start_game(index)
		begin_stage(2)
		var original_player := player
		circle.animate(3,10)
		hurt(circle_target,10000)
		check_wave_clear()
		check(campaign_won and not playing and is_instance_valid(ending),"hero %d final circle destruction starts the ending" % index)
		check(player==original_player and hero==index and not ui.visible,"ending retains the winning hero and hides battle HUD")
		var scene: Node3D = ending
		check(scene.guardian.decorative_parts>120 and scene.guardian.back_rings.size()==2 and scene.guardian.flames.size()==2,"guardian has detailed red-gold armour, twin backpack rings and leg flames")
		check(scene.guardian.position.y==12 and scene.page==-1 and scene.next_button.disabled,"guardian starts high in the sky before dialogue")
		scene.next_line()
		check(scene.page==-1,"dialogue cannot advance before landing")
		var previous_time := elapsed
		auto_test = false
		_process(0.05)
		auto_test = true
		check(elapsed==previous_time and scene.guardian.position.y<12 and scene.guardian.position.y>0,"ending animates descent while battle timers stay frozen")
		scene.advance(3)
		check(scene.landed and scene.guardian.position.y==0 and not scene.pillar.visible and scene.page==0,"landing completes before first dialogue appears")
		check(scene.dialogue.text.contains(HEROES[index].name) and scene.dialogue.text.contains("恭喜"),"congratulations address the current winning hero")
		scene.next_button.pressed.emit()
		check(scene.speaker.text==HEROES[index].name,"winning hero speaks in the conversation")
		var key := InputEventKey.new()
		key.keycode = KEY_ENTER
		key.pressed = true
		_unhandled_key_input(key)
		check(scene.dialogue.text.contains("欢迎加入银河超级护卫队"),"Enter advances to the galaxy team invitation")
		key.keycode = KEY_SPACE
		_unhandled_key_input(key)
		check(scene.speaker.text==HEROES[index].name and scene.dialogue.text.contains("愿意加入"),"space advances the hero acceptance")
		scene.next_line()
		check(scene.dialogue.text.contains("一起并肩作战") and is_instance_valid(ending),"guardian promises future adventures before settlement")
		scene.next_line()
		check(not is_instance_valid(ending) and scene.done and ui.visible and campaign_won,"finished dialogue restores the victory result screen")
		scene.finish_scene()
		check(campaign_won and not is_instance_valid(ending),"ending completion is idempotent")
	start_game(1)
	finish(true)
	var skipped: Node3D = ending
	var skip := InputEventKey.new()
	skip.keycode = KEY_ESCAPE
	skip.pressed = true
	_unhandled_key_input(skip)
	check(skipped.done and not is_instance_valid(ending) and ui.visible,"Escape skips descent safely to victory settlement")
	start_game(2)
	finish(true)
	var old_scene: Node3D = ending
	start_game(0)
	check(not is_instance_valid(ending) and old_scene.is_queued_for_deletion() and ui.visible and playing,"restart cleans ending actor and dialogue UI")
	finish(true)
	show_menu()
	check(not is_instance_valid(ending) and ui.visible and not playing,"returning to hero selection cleans ending scene")

func run_smoke_test() -> void:
	if test_steps>0:
		return
	test_steps += 1
	var mesh_arrays: Array = HeroVisual.beveled(Vector3.ONE).surface_get_arrays(0)
	var outward := true
	for i in range(0,mesh_arrays[Mesh.ARRAY_VERTEX].size(),3):
		var center: Vector3 = (mesh_arrays[Mesh.ARRAY_VERTEX][i]+mesh_arrays[Mesh.ARRAY_VERTEX][i+1]+mesh_arrays[Mesh.ARRAY_VERTEX][i+2])/3.0
		outward = outward and center.dot(mesh_arrays[Mesh.ARRAY_NORMAL][i])>0
	check(outward,"all beveled armor faces point outward")
	for index in range(3):
		start_game(index)
		check(hp==HEROES[index].hp,"hero %d stats" % index)
		check(player.identity==index and player.decorative_parts>100,"hero %d detailed model is used in battle" % index)
		player.animate(0.1,true)
		check(absf(player.leg_l.rotation.x)>0.1,"hero %d articulated walking" % index)
		player.animate(0.0,false)
		var idle_arm: float = player.arm_r.rotation.x
		player.attack()
		player.animate(0.1,false)
		check(absf(player.arm_r.rotation.x-idle_arm)>0.1,"hero %d weapon attack animation" % index)
		var e := spawn_enemy(0)
		e.node.position = Vector3(1,0,0)
		attack_clock = 0
		step(0.016)
		step(0.16)
		check(e.hp<60,"hero %d auto attack" % index)
		q_clock = 0
		skill(0)
		check(q_clock>0,"hero %d Q cooldown" % index)
		var target := spawn_enemy(2)
		target.node.position = player.position+Vector3(1,0,0)
		var previous_hp: float = target.hp
		skill(0)
		check(target.hp==previous_hp,"hero %d cannot bypass cooldown" % index)
		q_clock = 0
		skill(0)
		check(target.hp<previous_hp,"hero %d Q damage" % index)
		e_clock = 0
		var before: Vector3 = player.position
		skill(1)
		check(e_clock>0,"hero %d E cooldown" % index)
		var skill_effect: bool = player.position.distance_to(before)>5 and invuln>0 if index==0 else buff==8 if index==1 else target.slow>0 and target.hp<previous_hp-100
		check(skill_effect,"hero %d E effect" % index)
	start_game(0)
	invuln = 0
	var melee := spawn_enemy(0)
	melee.node.position = Vector3(1.2,0,0)
	melee.cooldown = 0
	step(0.01)
	check(hp==210,"melee enemy attacks")
	var spit := spawn_enemy(3)
	spit.node.position = Vector3(5,0,0)
	spit.cooldown = 0
	step(0.01)
	check(bullets.size()==1,"spitter launches projectile")
	start_game(0)
	var key := InputEventKey.new()
	key.keycode = KEY_ESCAPE
	key.pressed = true
	_unhandled_key_input(key)
	check(paused and not playing,"pause stops combat")
	_unhandled_key_input(key)
	check(playing and not paused,"escape resumes combat")
	xp = 8
	auto_test = false
	step(0.01)
	auto_test = true
	check(choosing and level==2,"experience opens upgrade selection")
	upgrade(0)
	check(not choosing,"upgrade resumes combat")
	start_game(0)
	for kind in range(5):
		var e := spawn_enemy(kind)
		check(e.hp==Campaign.stats(0,kind,ENEMIES[kind]).hp,"campaign enemy %d stats" % kind)
	var old_hp := hp
	invuln = 0
	damage_player(10)
	damage_player(10)
	check(hp==old_hp-10,"damage and invulnerability")
	upgrade(0)
	check(damage_mult>1,"damage upgrade")
	upgrade(1)
	check(max_hp==260,"health upgrade")
	var boss := enemies.back() as Dictionary
	hurt(boss,2000)
	check(playing and kills==1 and not campaign_won,"boss kill alone cannot bypass the campaign")
	start_game(1)
	invuln = 0
	damage_player(1000)
	check(not playing,"defeat")
	start_game(2)
	check(playing and kills==0 and hp==180,"restart resets state")
	for i in range(600):
		invuln = 1
		step(0.1)
	check(stage_spawned>0 and enemies.size()<=12 and elapsed>59,"60 second continuous circle-spawn simulation respects live cap")
	start_game(0)
	elapsed = 149.99
	step(0.02)
	check(not boss_spawned and stage_spawned<=1,"elapsed time cannot skip waves or spawn an early boss")
	elapsed = 239.99
	step(0.02)
	check(playing,"campaign has no former four-minute survival deadline")
	show_menu()
	check(portrait_rigs.size()==3 and portrait_rigs[0].identity==0 and portrait_rigs[2].identity==2,"three distinct live 3D previews")
	var portrait: Node3D = portrait_rigs[0]
	var before_rotation := portrait.rotation.y
	var motion := InputEventMouseMotion.new()
	motion.button_mask = MOUSE_BUTTON_MASK_LEFT
	motion.relative = Vector2(40,0)
	portrait.get_parent().get_parent().gui_input.emit(motion)
	check(portrait.rotation.y>before_rotation+0.5,"drag rotates the actual 3D model")
	combat_checks()
	campaign_visual_checks()
	campaign_flow_checks()
	camera_checks()
	balance_checks()
	third_skill_checks()
	enemy_attack_checks()
	click_movement_checks()
	ending_checks()
	print("SMOKE TEST COMPLETE")
	get_tree().quit(0)
